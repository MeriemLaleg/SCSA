\
/**
 1D SCSA Signal Filter
 - -* (C) Copyright 2015 King Abdullah University of Science and Technology
 Authors:
 Abderrazak Chahid (abderrazak.chahid@kaust.edu.sa)
 Taous-Meriem Laleg (taousmeriem.laleg@kaust.edu.sa)
 *
 *New displays function have been added to code,  Based on code written by
 *
 Ali Charara (ali.charara@kaust.edu.sa)
 David Keyes (david.keyes@kaust.edu.sa)
 Hatem Ltaief (hatem.ltaief@kaust.edu.sa)
 Taous-Meriem Laleg (taousmeriem.laleg@kaust.edu.sa)
 
 Redistribution  and  use  in  source and binary forms, with or without
 modification,  are  permitted  provided  that the following conditions
 are met:
 
 * Redistributions  of  source  code  must  retain  the above copyright
 * notice,  this  list  of  conditions  and  the  following  disclaimer.
 * Redistributions  in  binary  form must reproduce the above copyright
 * notice,  this list of conditions and the following disclaimer in the
 * documentation  and/or other materials provided with the distribution.
 * Neither  the  name of the King Abdullah University of Science and
chahid1/Excution_first/Code_first * Technology nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 *
 T *HIS  SOFTWARE  IS  PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 ``AS IS''  AND  ANY  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL  DAMAGES  (INCLUDING,  BUT NOT
 LIMITED  TO,  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA,  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY  OF  LIABILITY,  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF  THIS  SOFTWARE,  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/



#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <vector>
#include <mkl_lapack.h>
#include <mkl_blas.h>
#include <math.h>
#include <sys/time.h>


using namespace std;

// struct ==================================================================
struct baboon_opts
{
  string  dataFileName;
  string  deltaFileName;
  string  originImage;
  
  // matrix size
  int x_dim, y_dim;
  
  // scalars
  int d;
  float h;
  float gm;
  //float L;
  float fe;

  //params
  bool verbose;
  unsigned long buffer_size;
  char jobvl;
  char jobvr;
  
};
// function prototypes ==================================================================
bool readInput(baboon_opts* opts, float* &matBuffer);
bool writeBuffer(baboon_opts* opts, long int size, float* buffer, string fileName);
bool readBuffer(baboon_opts* opts, long int buffer_size, float* buffer, string fileName);

// bool process(baboon_opts* opts, float* matBuffer, float* deltaBuffer);
bool process(baboon_opts* opts, float* V, float* V0, float* D);

bool delta(int n, float* &deltaBuffer, float fex, float feh);

int parse_opts( int argc, char** argv, baboon_opts *opts );

float simp2(baboon_opts* opts, float* f, int n, float dx);

void kron(float* kap, int n, float* KAPX, int i, float* KAPY, int j, int rows, int cols, int gm);
void kronGM(float* kap, int n, float* KAPX, int i, float* KAPY, int j, int rows, int cols);

void syevd( const char jobz, const char uplo,
             const int n,
             float* a, const int lda, float* w,
             float* work, const int lwork, int* iwork, const int liwork, int info );
void gemv(  const char transa,
             const int m, const int n,
             const float alpha,
             const float *A, const int lda,
             const float *x, const int incx,
             const float beta,
             float *y, const int incy );
float dot(const int N, const float  *X, const int incX,
       const float  *Y, const int incY);

double gettime(void);

inline float square(float v){return v*v;}
float ipow(float v, int p){
  float res = v;
  for(int q = 1; q < p; q++) res *= v;
  return res;  
}


// *********************** CHAHID FUNCTION ROUTINES   ***********************

bool display_Objet_SCSA( baboon_opts *Objet_SCSA );
void Disp_matrx(int n,int m,float *Mtx_A);
void Disp_EigenValues(int n,float *Mtx_A);
bool readInput_modified(baboon_opts* opts, float* &matBuffer, float* &original);
// globals =================================================================

// defines ==================================================================
#define sqr(a_) ((a_)*(a_))
#define PI 3.141592653589793
#define USAGE printf("usage:\t./scsa \n \
\t --data filename\n \
\t -N image_dimension\n \
\t -d value_for_d (defaults to 2)\n \
\t -h value_for_h (defaults to 0.2)\n \
\t -gm value_for_gm (defaults to 4)\n \
\t -fe value_for_fe (defaults to 1)\n \
\t [-v] verbose_messages_ON\n \
\t --help generate this help message\n \
\n \
please consult the README file for detailed instructions.\n");

#define NUM_THREADS 40
// main ==================================================================
int main(int argc, char* argv[]){

  if(argc < 2){
    USAGE
    return 0;
  }
  
  baboon_opts opts;
      cout<<endl<<endl<<"******************  Preparing Images and needed Data   ******************"<< endl;
    

        
  if(!parse_opts(argc, argv, &opts)) return -1;
  if(!display_Objet_SCSA( &opts )) return -1;   
  float *matBuffer = NULL, *deltaBuffer = NULL, feh = 2.0*PI / opts.x_dim, *Image_ref = NULL;

//   if(!readInput(&opts, matBuffer)) return -1;
   if(!readInput_modified(&opts, matBuffer,Image_ref)) return -1;
  
  	  
  if(!writeBuffer(&opts,opts.x_dim*opts.x_dim,matBuffer,"scsa_in_not_processed.dat")) return -1;
 	  
// end

    cout<<" --> The input images has been read succesfully and stored in matBuffer, Image_ref.."<<endl;
    
     cout<<" --> Reference Image pixels"<<endl;
    
//     Disp_matrx(opts.x_dim,Objet_SCSA.y_dim,Image_ref);
    
    cout<<" --> Noisy Image pixels"<<endl;
    
//     Disp_matrx(opts.x_dim,Objet_SCSA.y_dim,matBuffer); 
    
   if(!delta(opts.x_dim, deltaBuffer, opts.fe, feh)) return -1;
    cout<<" --> Delta matrix has been generated."<<endl;
    cout<<" --> Delta Matrix"<<endl;
    //EX Disp_matrx(opts.x_dim,Objet_SCSA.y_dim,deltaBuffer);
     
       
  if(!process(&opts, matBuffer,Image_ref, deltaBuffer)) return -1;
    
  if(!writeBuffer(&opts,opts.x_dim*opts.x_dim,matBuffer,"scsa_output.dat")) return -1;

cout<<endl<<"End"<<endl;

  delete matBuffer;
  delete deltaBuffer;

  return 0;
}

// process ==================================================================
bool process(baboon_opts* opts, float* V, float* V0, float* D){
  float fe = opts->fe, feh = 2.0*PI / opts->x_dim, h2 = opts->h*opts->h,d;
  int n = opts->x_dim, n2 = n*n, lda = n;//, i,j,k;

  cout<<endl<<endl<<"***********************  SCSA process has started  **********************"<< endl;

  cout<<" --> The SCSA process has started. Please, Wait few seconds! : "<<endl;
  
  if(opts->verbose) printf("allocating memory...\n");
  
  float PSINNORX[n2*n], PSINNORY[n2*n];
  float KAPPAX[n2], KAPPAY[n2];
  int NX[n], NY[n];
  
  
  int lwork = 1 + 6*n + 2*n2, liwork = 3 + 5*n;
  float SC[n2];
  float lamda[n];//, lamdai[n];
  float work[lwork], psin[n2];
  int iwork[liwork], info;
  int indx_size = 0;
  float SC_hhD[n2];

  double comp_time = 0.0, eigen_time = 0.0, gemv_time = 0.0, cur_time;
  
  
  //compute L
  //M:   L = 2^(-d)*pi^(-d/2)*gamma(gm+1)/gamma(gm+1+(d/2)); % la constante universelle
  float L = ipow(4.0*PI, opts->d / 2);
  for(int k = opts->d / 2; k >= 1; k--){
    L *= opts->gm+k;
  }
  L = 1.0 / L;

  if(opts->verbose) printf("starting first loop... Begin, please wait ... :) \n");
  
  comp_time = gettime();

  memset(KAPPAX, 0, n2*sizeof(float));
  memset(KAPPAY, 0, n2*sizeof(float));
  

memcpy(SC_hhD, D, n2*sizeof(float));

    cout<<endl<<" --> SC_hhD Matrix OK!"<<endl;
 
    cout<<endl<<endl<<"*******************  Eigen Analysis of SC_hhD Matrix  *******************"<< endl;


  for(int j = 0; j < n2; j++)
    SC_hhD[j] *= -h2;

  int cur = 0;
  if(opts->verbose) printf("iter    ");
  for(int i = 0; i < n; i++){
    if(opts->verbose){ printf("\b\b\b\b%4d", cur++); fflush( stdout );}
    //rows
    
    //M: zx = 0.5*V(i,:);
    //M: Vx=diag(zx);
    //M: SCx=-h*h*D-Vx; % Schr\"odinger operator

    memcpy(SC, SC_hhD, n2*sizeof(float));
    

    for(int j = 0; j < n; j++)
      SC[j + j*n] -= 0.5 * V[i + j*n];
    
   //M: [psix,lamdax]=eig(SCx);% Eigenvalues & eigenfunction of Schr\"odinger operator
    
    cur_time = gettime();
    syevd( 'V', 'L',
            n,
            SC, n, lamda,
            work, lwork, iwork, liwork, info );
    eigen_time += gettime() - cur_time;
    
    //M:  % Negative eigenvalues
    //M:  tempx = diag(lamdax);
    //M:  indx = find(tempx<0);
    indx_size = 0;
 
    while(lamda[indx_size++] < 0);
    //M:  temp2x = tempx(indx);
    //M:  kappax = diag(sqrt(-temp2x));
    //we will not store temp2x and kappax, instead computed directly in Kappax
    
    //M:  % The associated $L^2$-normalized eigenfunctions.
    //M:  psinx = psix(:,indx(:,1));
    //M:  Ix= simp(psinx.^2,fe);
    //M:  psinnorx=psinx./sqrt(Ix);
    //M:  Kappax = diag(kappax);
    //M:  Nx = length(Kappax);
    //M:  NX(i) = Nx;
    //M:  KAPPAX(i,1:Nx) = Kappax';
    //M:  PSINNORX(1+n*(i-1):n*i,1:Nx) = psinnorx;
    
    int psin_size = n*indx_size;
    
 
    
            
    //psin = new float[psin_size];
    for(int j = 0; j < indx_size; j++){
      memcpy(psin+j*n, SC+j*n, n*sizeof(float));
      //memcpy(psin+j*n, psi+indx[j]*n, n*sizeof(float));
    }
    //writeBuffer(opts, psin_size, psin, string("psin128.dat"));return 0;
    //for(j = 0; j < psin_size; j++)
    //  psin[j] *= -1;
      //printf(" %f", psin[j]);
      //printf("\nI: %.15f\n", I);return 0;


    NX[i] = indx_size;

    for(int j = 0; j < NX[i]; j++){
      KAPPAX[i + j*n] = -lamda[j];//sqrt(-lamda[indx[j]]);// redundant, need square later
    }

    for(int k = 0; k < NX[i]; k++){
      float I = simp2(opts,psin+k*n, n, fe);//sqrt(simp2(psin, psin_size, fe));//
      for(int j = 0; j < n; j++){
        d = psin[j + k*n]*psin[j + k*n] / I;
        //d = pow(psin[j + k*n] / I,2.0);
        PSINNORX[n2*i + j + k*n] = d;
      }
    }

    //M:  %columns
    //M:  zy = 0.5*V(:,i);
    //M:  Vy = diag(zy);
    //M:  SCy=-h*h*D-Vy; % Schr\"odinger operator
    memcpy(SC, SC_hhD, n2*sizeof(float));
    for(int j = 0; j < n; j++)
      SC[j + j*n] -= 0.5 * V[j + i*n];
    //M:  [psiy,lamday]=eig(SCy); % Eigenvalues & eigenfunction of Schr\"odinger operator
    cur_time = gettime();
    syevd( 'V', 'L',
            n,
            SC, n, lamda,
            work, lwork, iwork, liwork, info );
    eigen_time += gettime() - cur_time;
        
    //M:  % Negative eigenvalues
    //M:  tempy = diag(lamday);
    //M:  indy = find(tempy<0);
    indx_size = 0;
    
      
    while(lamda[indx_size++] < 0);
    //M:  temp2y = tempy(indy);
    //M:  kappay = diag(sqrt(-temp2y));
    
    //M:  % The associated $L^2$-normalized eigenfunctions.
    //M:  psiny = psiy(:,indy(:,1));
    //M:  Iy= simp(psiny.^2,fe);
    //M:  psinnory = psiny./sqrt(Iy);
    //M:  Kappay = diag(kappay);
    //M:  Ny = length(Kappay);
    
    //M:  NY(i) = Ny;
    //M:  KAPPAY(i,1:Ny) = Kappay';
    //M:  PSINNORY(1+n*(i-1):n*i,1:Ny) = psinnory;
    psin_size = n*indx_size;
    for(int j = 0; j < indx_size; j++){
      memcpy(psin+j*n, SC+j*n, n*sizeof(float));
    }
  
    NY[i] = indx_size;
    
    for(int j = 0; j < NY[i]; j++){
      KAPPAY[i + j*n] = -lamda[j];//sqrt(-lamda[indx[j]]);// redundant, need square later
    }

    for(int k = 0; k < NY[i]; k++){
        
      float I = simp2(opts,psin+k*n, n, fe);//sqrt(simp2(psin, psin_size, fe));//
      for(int j = 0; j < n; j++){
        d = psin[j + k*n]*psin[j + k*n] / I;
        //d = pow(psin[j + k*n] / I,2.0);
        PSINNORY[n2*i + j + k*n] = d;
//          cout<<endl<<endl<<"***********************  SCSA ERROR Detected3  **********************"<< endl;
//           cout<<endl<<endl<<"indx="<< n2*i + j + k*n<< " / "<<n2*n <<endl;
    
    
      }
    }
    
  }
      
        cout<<endl<<" --> Negative Eigen  values  ( Culoumns)  OK!";
          
     
  
  if(opts->verbose) printf(" \n\nstarting second loop... Construction of image. Please wait... :) \n");
  //M:  V1 = zeros(n,n);
  //M:  for i = 1 :n
  //M:    etape = i;
  //M:    for j = 1: n
  //M:      %tic
  //M:      Kap = (kron((KAPPAX(i,1:NX(i)).^2)',ones(1,NY(j))) + kron((KAPPAY(j,1:NY(j)).^2),ones(NX(i),1))).^(gm);
  //M:      %toc
  //M:      %tic
  //M:      V1(i,j) = V1(i,j) +(h^2/L)*(PSINNORX(j+(i-1)*n,1:NX(i)).^2)*Kap*(PSINNORY(i+(j-1)*n,1:NY(j)).^2)';
  //M:      %toc
  //M:    end
  //M:  end
  //M:  V2 = zeros(n,n);
  //M:  V2 = (V1.^(2/(2*gm+d)));
  //M:  ERR =(abs(V-V2))./max(max(V)); % Relatif error
  //M:  mse = mean2((V - V2).^2);
  //M:  psnr = 10*log10(1/mse);

  
  float V1[n2];
  float Kap[n2];
  float v[n];
  float alpha = 1.0, beta = 0.0;
  int incv = 1;
  float p = 2.0/(2.0*opts->gm+opts->d), mse0 = 0.0, psnr0,mse = 0.0, psnr, h2_L = h2 / L;

  try{
  
  if(opts->verbose) printf("%%        ");
  memset(V1, 0, n2*sizeof(float));
  
  for(int i = 0; i < n; i++){
    for(int j = 0; j < n; j++){
      memset(Kap, 0, n2*sizeof(float));

      kron(Kap, n, KAPPAX, i, KAPPAY, j, NX[i], NY[j], opts->gm);

      memset(v, 0, n*sizeof(float));
      cur_time = gettime();
      gemv('N',
           NX[i], NY[j],
           alpha,
           Kap, NX[i],
           PSINNORY+j*n2+i, n,
           beta,
           v, incv );
      gemv_time += gettime() - cur_time;

      V1[i + j*n] = h2_L * dot(NX[i], PSINNORX+i*n2+j, n, v, incv);

//cout<< "("<<V[i + j*n]<<","<<V1[i + j*n]<<") ";

      V1[i + j*n] = pow(V1[i + j*n], p);

      mse += square(V0[i + j*n] - V1[i + j*n]);
      mse0 += square(V0[i + j*n] - V[i + j*n]);
      
      
    }
  }

 mse0 /= n2;
 psnr0 = 10.0* log10(1.0/mse0);
 
 mse /= n2;
 psnr = 10.0* log10(1.0/mse);
 
  comp_time = gettime() - comp_time;

  }catch(...){
    printf("caught exception ");
  }
  
   
    cout<<endl<<endl<<endl<<endl<<"************************   2D1D SCSA Diagnosis   ************************"<<endl;

    cout<<" The computations are done with the following results :  "<< endl;
    cout<< "==> Performances  :"<<endl;
    cout<<"Original:   MSE = "<<mse0<<  "  PSNR = "<<psnr0<<endl;
    cout<<"Denoised:   MSE = "<<mse<<  "  PSNR = "<<psnr<<endl<< endl;
    cout<< "==> Execution Time:   Totale Time  = "<<comp_time<<" sec"<< endl;
    cout<< "EigenAnalysis = "<<100*eigen_time/comp_time<< "%  "<<endl;
    cout<<"gemv = "<<100*gemv_time/comp_time<< "%  "<<endl<<endl;
    cout<< "==> EigenValues observation :"<<endl;

// chahidd added line 
memcpy(V,V1, n2*sizeof(float)); 

int MINX_size=2*n,MAXX_size=0, MINY_size=2*n,MAXY_size=0;  
for (int j=0;j<n;j++)
    
{
    if (MAXX_size<NX[j] )    
        {MAXX_size=NX[j]; } 
    
    if (MINX_size>NX[j] )    
        {MINX_size=NX[j]; } 
    
    if (MAXY_size<NY[j] )    
        {MAXY_size=NY[j]; } 
    
    if (MINY_size>NY[j] )    
        {MINY_size=NY[j]; }    
    
}
cout<<endl<<" # Negative EigenValues X :  Min = "<<MINX_size<<"  Max = "<<MAXX_size<<endl; 
cout<<endl<<" # Negative EigenValues Y :  Min = "<<MINY_size<<"  Max = "<<MAXY_size<<endl<<endl; 
// end

   
cout<<endl<<"**********************       End of SCSA process     ********************"<<endl;


  return 1;
}

// kron ==================================================================
void kron(float* kap, int n, float* KAPX, int i, float* KAPY, int j, int rows, int cols, int gm){
  for(int r = 0; r < rows; r++){
    for(int c = 0; c < cols; c++){
      float v = KAPX[i+r*n]+KAPY[j+c*n];
      kap[r + c*rows] = v;
      for(int q = 1; q < gm; q++)
        kap[r + c*rows] *= v;
    }
  }
}
  
// simp2 ==================================================================
float simp2(baboon_opts* opts, float* f, int n, float dx){
//M:  % Author: Taous Meriem Laleg
//M:  %  This function returns the numerical integration of a function f
//M:  %  using the Simpson method
  
//M:  n=length(f);
//M:  I(1)=1/3*f(1)*dx;
//M:  I(2)=1/3*(f(1)+f(2))*dx;

//M:  for i=3:n
//M:    if(mod(i,2)==0)
//M:      I(i)=I(i-1)+(1/3*f(i)+1/3*f(i-1))*dx;
//M:    else
//M:      I(i)=I(i-1)+(1/3*f(i)+f(i-1))*dx;
//M:    end
//M:  end
//M:  y=I(n);
  float I;//[2];
  I = (sqr(f[0])+sqr(f[1]))*dx / 3.0;

  for(int i = 2; i < n; i++){
    I += sqr(f[i])*dx/3.0 + sqr(f[i-1])*dx*(i%2?1.0/3.0:1.0);
  }
  return I;
}
  
// delta ==================================================================
bool delta(int n, float* &deltaBuffer, float fex, float feh){
  int ex, p;//float ex[n-1];
  float dx, test_bx[n-1], test_tx[n-1], factor = feh/fex;
  factor *= factor;
  
  if(n%2 == 0){
    p = 1;
    dx = -(PI*PI)/(3.0*feh*feh)-1.0/6.0;
    for(int i = 0; i < n-1; i+=2){
      ex = n-i-1;
      p *= -1; 
      test_bx[i] = test_tx[i] = -0.5 * p / square(sin( ex * feh * 0.5));
      ex = n-i-2;
      p *= -1;
      test_bx[i+1] = test_tx[i+1] = -0.5 * p / square(sin( ex * feh * 0.5));
    }
  }else{
    dx = -(PI*PI) / (3.0*feh*feh) - 1.0/12.0;
    for(int i = 0; i < n-1; i++){
      ex = n-i-1;
      test_bx[i] = -0.5 * pow(-1,  ex) * cot( ex * feh * 0.5) / (sin( ex * feh * 0.5));
      test_tx[i] = -0.5 * pow(-1, -ex) * cot(-ex * feh * 0.5) / (sin(-ex * feh * 0.5));
    }
  }
  
  unsigned long buffer_size = n * n;
  deltaBuffer = new float[ buffer_size ];
  if(!deltaBuffer)
  {
    cout << "out of memory, could not allocate "<< buffer_size <<" of memory!" << endl;
    return false;
  }

  int lda = n+1;
  
  for(int r = 0; r < n; r++){
    deltaBuffer[r*lda] = dx * factor;
  }
  float vL, vU;
  for(int r = 1; r < n; r++){
    vL = test_bx[n-r-1] * factor;
    vU = test_tx[n-r-1] * factor;
    for(int c = 0; c < n-r; c++){
      deltaBuffer[r   + c*lda] = vL;
      deltaBuffer[r*n + c*lda] = vU;
    }
  }
  return true;
}

// wrapper functions for BLAS ==================================================================
void syevd( const char jobz, const char uplo,
            const int n,
            float* a, const int lda, float* w,
            float* work, const int lwork, int* iwork, const int liwork, int info ){
  ssyevd( &jobz, &uplo,
          &n,
          a, &lda, w,
          work, &lwork, iwork, &liwork, &info );
}

void gemv( const char transa,
           const int m, const int n,
           const float alpha,
           const float *A, const int lda,
           const float *x, const int incx,
           const float beta,
           float *y, const int incy ){
  sgemv(&transa,
        &m, &n,
        &alpha,
        A, &lda,
        x, &incx,
        &beta,
        y, &incy );
}

float  dot(const int N, const float  *X, const int incX,
           const float  *Y, const int incY){
  return sdot(&N, X, &incX,
              Y, &incY);
}

// readInput ==================================================================
bool readInput(baboon_opts* opts, float* &matBuffer)//, float* &deltaBuffer)
{
  if(opts->verbose) cout << "reading data from file: " << opts->dataFileName << ", data of size: " << opts->x_dim << "x" << opts->y_dim << endl;
  FILE* infile;
  //load matrix data
  infile = fopen(opts->dataFileName.c_str(), "rb");
  if(!infile)
  {
    cout << "could not open input file!" << endl; return 0;
  }
  
  opts->buffer_size = opts->x_dim * opts->y_dim;
  if(opts->verbose) cout << "reading buffer of size: " << opts->buffer_size << endl;
  matBuffer = new float[ opts->buffer_size ];
  if(!matBuffer)
  {
    cout << "out of memory, could not allocate "<< opts->buffer_size <<" of memory!" << endl;
    fclose(infile);
    return false;
  }
  unsigned long res = fread((void*)matBuffer, sizeof(float), opts->buffer_size, infile);
  if(ferror(infile)){
    cout << "error reading file!" << endl;
  }
  if(opts->verbose) cout << "did read " << res << " entries, content not checked though!" << endl;
  fclose(infile);
    
  return true;
}

// readInput ==================================================================
bool readBuffer(baboon_opts* opts, long int buffer_size, float* buffer, string fileName)
{
  if(opts->verbose) cout << "reading data from file: " << fileName << endl;
  FILE* infile;
  //load matrix data
  infile = fopen(fileName.c_str(), "rb");
  if(!infile)
  {
    cout << "could not open input file!" << endl; return 0;
  }
  
  if(opts->verbose) cout << "reading buffer of size: " << buffer_size << endl;
  unsigned long res = fread((void*)buffer, sizeof(float), buffer_size, infile);
  if(ferror(infile)){
    cout << "error reading file!" << endl;
    return 0;
  }
  if(opts->verbose) cout << "did read " << res << " entries, content not checked though!" << endl;
  fclose(infile);
    
  return true;
}

// writeOutput ==================================================================
bool writeBuffer(baboon_opts* opts, long int size, float* buffer, string fileName)
{
  if(opts->verbose) cout << "writeing data to file: " << fileName << ", data of size: " << size << endl;
  FILE* outfile;
  //load matrix data
  outfile = fopen(fileName.c_str(), "wb");
  if(!outfile)
  {
    cout << "could not open output file!" << endl; return 0;
  }
  
  unsigned long res = fwrite((void*)buffer, sizeof(float), size, outfile);
  if(ferror(outfile)){
    cout << "error writing to file!" << endl;
    return 0;
  }
  fclose(outfile);
   
cout<<" --> "<<fileName<<" has been created succefully."<<endl; 
  return true;
}

// parse_opts ==================================================================
int parse_opts( int argc, char** argv, baboon_opts *opts )
{
  // fill in default values
  opts->x_dim = 512;
  opts->y_dim = 512;

  opts->d = 2;
  opts->h = 0.2;
  opts->gm = 0.5;
  opts->fe = 1.0;
  //opts->L = 0.015915494309190;
  opts->dataFileName = "baboon_b.dat";
  opts->deltaFileName = "baboon_D.dat";
  opts->jobvl = 'N';
  opts->jobvr = 'V';
  opts->verbose= false;

  int info;
  for( int i = 1; i < argc; ++i ) {
    // ----- matrix size
    // each -N fills in next entry of size
    if ( strcmp("-N", argv[i]) == 0 && i+1 < argc ) {
      i++;
      int m, n;
      info = sscanf( argv[i], "%d:%d", &m, &n);
      if ( info == 2 && m > 0 && n > 0 ) {
        opts->x_dim = m;
        opts->y_dim = n;
      }
      else if ( info == 1 && m >= 0 ) {
        opts->x_dim = m;
        opts->y_dim = m;// implicitly
      }
      else {
        fprintf( stderr, "error: -N %s is invalid; ensure m >= 0, n >= 0, info=%d, m=%d, n=%d.\n",
                argv[i],info,m,n);
        exit(1);
      }
    }

    
    else if ( strcmp("--data", argv[i]) == 0 && i+1 < argc ) {
      opts->dataFileName = argv[++i];
      opts->originImage = argv[++i];
    }
    else if ( strcmp("--delta", argv[i]) == 0 && i+1 < argc ) {
      opts->deltaFileName = argv[++i];
      
    }
    else if ( strcmp("-d",    argv[i]) == 0 && i+1 < argc ) {
      opts->d = atoi( argv[++i] );
    }
    else if ( strcmp("-h", argv[i]) == 0 && i+1 < argc ) {
      opts->h = atof( argv[++i] );
    }
    else if ( strcmp("-fe", argv[i]) == 0 && i+1 < argc ) {
      opts->fe = atof( argv[++i] );
    }
    else if ( strcmp("-gm",   argv[i]) == 0 && i+1 < argc ) {
//       opts->gm = atoi( argv[++i] );
      opts->gm = atof( argv[++i] );
      
      //opts->L = 1.0 / (4*PI*(opts->gm+1));
    }/*
    else if ( strcmp("-L", argv[i]) == 0 && i+1 < argc ) {
      opts->L = atof( argv[++i] );
    }*/
    else if ( strcmp("-v",  argv[i]) == 0 ) { opts->verbose= true;  }

    // ----- usage
    else if ( strcmp("--help", argv[i]) == 0 ) {
      USAGE
      exit(0);
    }
    else {
      fprintf( stderr, "error: unrecognized option %s\n", argv[i] );
      exit(1);
    }
  }

  return 1;
}



double gettime(void)
{
  struct timeval tp;
  gettimeofday( &tp, NULL );
  return tp.tv_sec + 1e-6 * tp.tv_usec;
}


// *********************** CHAHID FUNCTION ROUTINES   ***********************

/*======================== Displays   ===================
 __________________________________________________________________
 | This function Shows the buffer in  Matrix representation         |
 | ________________________________________________________________ |*/

void Disp_matrx(int n,int m,float *Mtx_A) {
    cout<<endl<<" _______  Displaying Buffer :"<< n*m<<" Values __________"<<endl<<endl;
    
    for (int i=0; i<n*m; i++){
        printf(" | %f | ",Mtx_A [i] );}
    
    cout<<endl<<endl<<" __________  Displaying Matrix :"<< n<<"X"<<m<<" _____________"<<endl<<endl;
    
    for (int i=0; i<n; i++) {
        for (int j=0; j<m; j++) {
            
            printf(" | %f | ",Mtx_A [i+j*n] );
        }
        
        printf(" \n");}
    
}



/*======================== Displays   ===================
 __________________________________________________________________
 | This function Shows the buffer in  Matrix representation         |
 | ________________________________________________________________ |*/

void Disp_EigenValues(int n,float *Vector_A) {
    
    printf(" \n\n_______  Displaying Eigen Values  Vector  __________\n\n");
    
    for (int j=0; j<n; j++) {
        
        printf(" | %f | ",Vector_A[j] );
        
        
    }
    
    
    
}


/*======================= Display  Image information    =======================
 
 ___________________________________________________________________________
 |   This function displays the image information stored in  Objet_SCSA     |
 | _________________________________________________________________________|*/




bool display_Objet_SCSA( baboon_opts *Objet_SCSA )
{
    cout<< " ============== Image Informations =============="<<endl;
    cout<< "|  Dimmension : " <<   Objet_SCSA->x_dim<<  " X "<<   Objet_SCSA->y_dim<< " Pixels."<<endl;
    //Objet_SCSA->L = 0.015915494309190;
    cout<< "|  Reference image   : "<<    Objet_SCSA->originImage <<" ."<<endl;
    cout<< "|  Input Noisy image : "<<    Objet_SCSA->dataFileName <<" ."<<endl;
    cout<< "|*************** SCSA Parameters *****************"<<endl;
    cout<< "| h== "<<Objet_SCSA->h << "    d="<< Objet_SCSA->d<< "    gm="<<Objet_SCSA->gm << "    fe="<<Objet_SCSA->fe << "."<<endl;
    cout<< "| jobvl= "<< Objet_SCSA->jobvl << "    jobvr="<< Objet_SCSA->jobvr<< "    verbose="<< Objet_SCSA->verbose<< "."<<endl;
    cout<< " ================================================="<<endl;
    return 1;
}



/*================================ READ DATA    ===============================
 ____________________________________________________________________________
 |         This function  reads the ".dat" file stored in Objet_SCSA          |
 |                  to the buffer (table Pointer )  matBuffer                 |
 | __________________________________________________________________________ |*/


bool readInput_modified(baboon_opts* opts, float* &matBuffer, float* &original)//, float* &deltaBuffer)
{
    if(opts->verbose) cout << "reading data from file: " << opts->dataFileName << ", data of size: " << opts->x_dim << "x" << opts->y_dim << endl;
    FILE* infile;
    
    // load Noisy Image
    
    cout<<endl<<"   --> Noisy Image : "<< opts->dataFileName.c_str();
    infile = fopen(opts->dataFileName.c_str(), "rb");
    if(!infile)
    {
        cout << "could not open input file!" << endl; return 0;
    }
    
    opts->buffer_size = opts->x_dim * opts->y_dim;
    
    if(opts->verbose) cout << "reading buffer of size: " << opts->buffer_size << endl;
    matBuffer = new float[ opts->buffer_size ];
    if(!matBuffer)
    {
        cout << "out of memory, could not allocate "<< opts->buffer_size <<" of memory!" << endl;
        fclose(infile);
        return false;
    }
    unsigned long res = fread((void*)matBuffer, sizeof(float), opts->buffer_size, infile);
    if(ferror(infile)){
        cout << "error reading file!" << endl;
    }
    if(opts->verbose) cout << "did read " << res << " entries, content not checked though!" << endl;
    fclose(infile);
    
        // load Original Image 
    
    cout<<endl<<"   --> Reference Image :  "<< opts->originImage.c_str()<<endl<<endl;
    infile = fopen(opts->originImage.c_str(), "rb");
    if(!infile)
    {
        cout << "could not open input file!" << endl; return 0;
    }
    
    opts->buffer_size = opts->x_dim * opts->y_dim;
    
    if(opts->verbose) cout << "reading buffer of size: " << opts->buffer_size << endl;
    original = new float[ opts->buffer_size ];
    if(!original)
    {
        cout << "out of memory, could not allocate "<< opts->buffer_size <<" of memory!" << endl;
        fclose(infile);
        return false;
    }
    unsigned long res2 = fread((void*)original, sizeof(float), opts->buffer_size, infile);
    if(ferror(infile)){
        cout << "error reading file!" << endl;
    }
    if(opts->verbose) cout << "did read " << res2 << " entries, content not checked though!" << endl;
    fclose(infile);
    
    return true;
}

