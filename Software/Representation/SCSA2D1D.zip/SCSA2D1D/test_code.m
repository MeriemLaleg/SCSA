/*================================ READ DATA    ===============================
 ____________________________________________________________________________
 |         This function  reads the ".dat" file stored in Objet_SCSA          |
 |                  to the buffer (table Pointer )  matBuffer                 |
 | __________________________________________________________________________ |*/


bool readInput_modified(baboon_opts* opts, float* &matBuffer, float* &original)//, float* &deltaBuffer)
{
    if(opts->verbose) cout << "reading data from file: " << opts->dataFileName << ", data of size: " << opts->x_dim << "x" << opts->y_dim << endl;
    FILE* infile;
    
    // load Noisy Image
    
    cout<<endl<<"   --> Noisy Image : "<< opts->dataFileName.c_str();
    infile = fopen(opts->dataFileName.c_str(), "rb");
    if(!infile)
    {
        cout << "could not open input file!" << endl; return 0;
    }
    
    opts->buffer_size = opts->x_dim * opts->y_dim;
    
    if(opts->verbose) cout << "reading buffer of size: " << opts->buffer_size << endl;
    matBuffer = new float[ opts->buffer_size ];
    if(!matBuffer)
    {
        cout << "out of memory, could not allocate "<< opts->buffer_size <<" of memory!" << endl;
        fclose(infile);
        return false;
    }
    unsigned long res = fread((void*)matBuffer, sizeof(float), opts->buffer_size, infile);
    if(ferror(infile)){
        cout << "error reading file!" << endl;
    }
    if(opts->verbose) cout << "did read " << res << " entries, content not checked though!" << endl;
    fclose(infile);
    
        // load Original Image 
    
    cout<<endl<<"   --> Reference Image :  "<< opts->originImage.c_str()<<endl;
    infile = fopen(opts->originImage.c_str(), "rb");
    if(!infile)
    {
        cout << "could not open input file!" << endl; return 0;
    }
    
    opts->buffer_size = opts->x_dim * opts->y_dim;
    
    if(opts->verbose) cout << "reading buffer of size: " << opts->buffer_size << endl;
    original = new float[ opts->buffer_size ];
    if(!original)
    {
        cout << "out of memory, could not allocate "<< opts->buffer_size <<" of memory!" << endl;
        fclose(infile);
        return false;
    }
    unsigned long res2 = fread((void*)original, sizeof(float), opts->buffer_size, infile);
    if(ferror(infile)){
        cout << "error reading file!" << endl;
    }
    if(opts->verbose) cout << "did read " << res2 << " entries, content not checked though!" << endl;
    fclose(infile);
    
    return true;
}

