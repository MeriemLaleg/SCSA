%*******************************************************************************
%  SCSA Parameter used for C-Code execution  

% direct_data='./';
% fid = fopen(strcat(direct_data,'scsa_parameters.dat'),'r');
% scsa_param = fread(fid,inf,'double');
% fclose(fid);
% 
% h = scsa_param(2);
% img_size= scsa_param(1);
% gm = scsa_param(4);
% fe = scsa_param(3);
h=0.255;gm=0.5;fe=1;
%*******************************************************************************
% load('var.mat','idx')
N=64;
direct_data='./';
fid = fopen(strcat(direct_data,'scsa_original',num2str(N),'.dat'),'r');
image_buffer = fread(fid,inf,'single');
fclose(fid);
img_size=sqrt(max(size(image_buffer)));
original_image=reshape(image_buffer, img_size, img_size);
original_image=single(original_image);


fid = fopen(strcat(direct_data,'scsa_input',num2str(N),'.dat'),'r');
image_buffer = fread(fid,inf,'single');
fclose(fid);
img_size=sqrt(max(size(image_buffer)));
noisy_image=reshape(image_buffer, img_size, img_size);
noisy_image=single(noisy_image);


fid = fopen(strcat(direct_data,'scsa_in_not_processed.dat'),'r');
upload_buffer_in = fread(fid,inf,'single');
fclose(fid);

img_size=sqrt(max(size(upload_buffer_in)));

factr=0;
img_size=img_size/(2^factr);

check_C__image=reshape(upload_buffer_in, img_size, img_size);
check_C__image=single(check_C__image);

FileID = fopen(strcat(direct_data,'scsa_output.dat'),'r');
upload_buffer_out = fread(FileID,inf,'single');
fclose(FileID);

denoised_image=reshape(upload_buffer_out, img_size, img_size);
denoised_image=single(denoised_image);

%% Evaluation with original 

ERR0 =(abs(noisy_image-original_image))./max(max(check_C__image)); % Relatif error

MSE0 = mean2((noisy_image - original_image).^2)
PSNR0 = 10*log10(1/MSE0)
psnr_msg0=strcat(' PSNR =   ',num2str(PSNR0))


%% Evaluation denoising

ERR =(abs(denoised_image-original_image))./max(max(check_C__image)); % Relatif error

MSE = mean2((original_image - denoised_image).^2)
PSNR = 10*log10(1/MSE)
psnr_msg=strcat(' PSNR =   ',num2str(PSNR))
%% Plots


figure(2)

subplot(2,2,1);imshow(original_image,[]);
               title(strcat('Original Image: Size =',num2str(img_size),'*',num2str(img_size))) ;

subplot(2,2,2);imshow(noisy_image,[]);
               title(strcat('Noisy Image: ',psnr_msg)) ;
               
               
subplot(2,2,3);imshow(check_C__image,[]);title('Read Noisy Image by C code') ;
                ylabel(' C++ implementation. ') ;

subplot(2,2,4);imshow(denoised_image,[]);title('Denoised Image') ;
                
                xlabel(strcat(' Size =',num2str(img_size),'*',num2str(img_size),'  h=',num2str(h),'  gm=',num2str(gm),'  fe=',num2str(fe))) ;

               
set(figure(1),'units','normalized','outerposition',[0 0 1 1])
% saveas(figure(1),strcat('.\Results\C_implementation_RSL_',num2str(idx),'.bmp'));    
% idx=idx+1;
% save('var.mat','idx')
