READ ME for scsa_1 tool:

COMPILATION:
  To build this program's executable file, please follow following simple steps:

  - make sure you have intel compiler (icc) and intell MKL library installed on your environment, you can simply load these by typing:
    %>  module load intel/15
    in case a different intel compiler is loaded, please edit the make.inc file to reflect that

  - cd to code location
  - compile the code by typing:
    %> make
    


USAGE:
- for quick help on program parameters, type:
  %> ./scsa_1 --help

- to generate data please use the Data_generation.m attached Matlab file. to output files will be stored in Execution_Data folder 

- sample usage:
  - assume your signal file has been saved in a binary file named "scsa_input256.dat" as per previous step and signal size is set to 256:
  - cd to your folder where the executable resides
  - type the following on the command line
    %> ./scsa_1 --data scsa_input256.dat -N 256

  - to change input parameters, type for example:
    %> ./scsa_1 --data scsa_input256.dat -N 256 -d 4 -h 0.4 -gm 6 -fe 2

    
IMPORTANT:
  - code assumes the 'gm' parameter is an integer value
  - code assumes 'd' parameter is an integer value divisible by 2


