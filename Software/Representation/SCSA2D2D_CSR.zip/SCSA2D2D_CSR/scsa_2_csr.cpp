/**
2D SCSA Image Filtering
 *
 - -* (C) Copyright 2016 King Abdullah University of Science and Technology
 Authors:
 Abderrazak Chahid (abderrazak.chahid@kaust.edu.sa)
 Taous-Meriem Laleg (taousmeriem.laleg@kaust.edu.sa)
 *
 *New function get added to code, CHAHID ROUTINE, Some variable have been changed 
 * (Class_SCSA = baboon_opts, Objet_SCSA=opts, ) , Class_SCSA, readInput have been 
 * changes to includ the original image for PSNR meas
 * Based on  Program written on 2015 by : 

 Ali Charara (ali.charara@kaust.edu.sa)
 David Keyes (david.keyes@kaust.edu.sa)
 Hatem Ltaief (hatem.ltaief@kaust.edu.sa)
 Taous-Meriem Laleg (taousmeriem.laleg@kaust.edu.sa)
 
 Redistribution  and  use  in  source and binary forms, with or without
 modification,  are  permitted  provided  that the following conditions
 are met:
 
 * Redistributions  of  source  code  must  retain  the above copyright
 * notice,  this  list  of  conditions  and  the  following  disclaimer.
 * Redistributions  in  binary  form must reproduce the above copyright
 * notice,  this list of conditions and the following disclaimer in the
 * documentation  and/or other materials provided with the distribution.
 * Neither  the  name of the King Abdullah University of Science and
chahid1/Excution_first/Code_first * Technology nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 *
 T *HIS  SOFTWARE  IS  PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 ``AS IS''  AND  ANY  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL  DAMAGES  (INCLUDING,  BUT NOT
 LIMITED  TO,  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA,  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY  OF  LIABILITY,  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF  THIS  SOFTWARE,  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

#include <stdio.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <vector>
#include <mkl_lapack.h>
#include <mkl_blas.h>
#include <math.h>
#include <sys/time.h>
// Include Sparse Solver

using namespace std;

// *********************** Type DEFINITION  ***********************
// struct ==================================================================
//  Class_SCSA : it includes the needed parameter and data for SCSA algorithm

struct Class_SCSA
{
    // name of needed data in .dat format
    string  dataFileName;
    string  deltaFileName;
    string  originImage;
    
    
    // matrix size
    int x_dim, y_dim;
    
    // SCSA Prameter
    int d;
    float h;
    int gm;
    float fe;
    
    //paramters and flags
    
    bool verbose;
    unsigned long buffer_size;
    char jobvl;
    char jobvr;
    
};

struct csr 
/*This codes are partially taken from: 
http://stackoverflow.com/questions/33599750/read-a-file-with-a-sparse-matrix-and-generate-csr
*/{
    int row_count;
    int *row_indices;
    float *values;
    int *column_indices;
};


// *********************** Type DEFINITION  ***********************

// function prototypes ==================================================================
// // prepare data

bool readInput(Class_SCSA* Objet_SCSA, float* &matBuffer, float* &original);
bool writeBuffer(Class_SCSA* Objet_SCSA, long int size, float* buffer, string fileName);

// // SCSA features

bool process(Class_SCSA* Objet_SCSA, float* matBuffer, float* deltaBuffer);

bool delta(int n, float* &deltaBuffer, float fex, float feh);

int parse_Objet_SCSA( int argc, char** argv, Class_SCSA *Objet_SCSA );

float simp2(Class_SCSA* Objet_SCSA, float* f, int n, float dx);

// // Linear Algebra operations

void kron(float* kap, int n, float* KAPX, int i, float* KAPY, int j, int rows, int cols, int gm);

void kronGM(float* kap, int n, float* KAPX, int i, float* KAPY, int j, int rows, int cols);

void syevd( const char jobz, const char uplo,
           const int n,
           float* a, const int lda, float* w,
           float* work, const int lwork, int* iwork, const int liwork, int info );

void gemv(  const char transa,
          const int m, const int n,
          const float alpha,
          const float *A, const int lda,
          const float *x, const int incx,
          const float beta,
          float *y, const int incy );
float dot(const int N, const float  *X, const int incX,
          const float  *Y, const int incY);

double gettime(void);

inline float square(float v){return v*v;}

float ipow(float v, int p){
    float res = v;
    //D    cout<<endl<<" power to =" << p<<endl;
    
    for(int q = 1; q < p; q++) res *= v;
    return res;
}


// ************************ GLOBALS   ***************************

/*========================= defines  ============================*/

#define sqr(a_) ((a_)*(a_))
#define PI 3.141592653589793
#define USAGE printf("usage:\t./scsa \n \
\t --data filename\n \
\t -N image_dimension\n \
\t -d value_for_d (defaults to 2)\n \
\t -h value_for_h (defaults to 0.2)\n \
\t -gm value_for_gm (defaults to 4)\n \
\t -fe value_for_fe (defaults to 1)\n \
\t [-v] verbose_messages_ON\n \
\t --help generate this help message\n \
\n \
please consult the README file for detailed instructions.\n");


// *********************** CHAHID FUNCTION ROUTINES   ***********************

void kron_prod (float* kprod,  float* a, int ma, int na,  float* b, int mb, int nb);
bool display_Objet_SCSA( Class_SCSA *Objet_SCSA );
void Matrx_Unit(int n,int m,float *Mtx_unit);
float SC_Sum(float h, int n,float *D1,float *D2,float *V,float *SC,int *NZ);
bool SCSA_2D2_full(Class_SCSA* Objet_SCSA, float* imag, float* Delta_mtrx);
void Disp_matrx(int n,int m,float *Mtx_A);
void Disp_EigenValues(int n,float *Mtx_A);
float simp3(float* f, int n, float dx);

#define NUM_THREADS 40

// *********************** MAIN FUNCTION   ***********************



int main(int argc, char* argv[]){
    
    if(argc < 2){
        USAGE
        return 0;
    }
    
    Class_SCSA Objet_SCSA;
    
    cout<<endl<<endl<<"******************  Preparing Images and needed Data   ******************"<< endl;
    
    if(!parse_Objet_SCSA(argc, argv, &Objet_SCSA)) return -1;
    
    if(!display_Objet_SCSA( &Objet_SCSA )) return -1;                               // Display
    
    float *matBuffer = NULL, *deltaBuffer = NULL, feh = 2.0*PI / Objet_SCSA.x_dim, *Image_ref = NULL;
    
    if(!readInput(&Objet_SCSA, matBuffer,Image_ref)) return -1;
    cout<<" --> The input images has been read succesfully and stored in matBuffer, Image_ref.."<<endl;
    
     cout<<" --> Reference Image pixels"<<endl;
    
//     Disp_matrx(Objet_SCSA.x_dim,Objet_SCSA.y_dim,Image_ref);
    
    cout<<" --> Noisy Image pixels"<<endl;
    
//     Disp_matrx(Objet_SCSA.x_dim,Objet_SCSA.y_dim,matBuffer);
    
    if(!writeBuffer(&Objet_SCSA,Objet_SCSA.x_dim*Objet_SCSA.x_dim,matBuffer,"scsa_in_not_processed.dat")) return -1;
    
    float scsa_parmter[5];
    
    scsa_parmter[0]=Objet_SCSA.x_dim;
    scsa_parmter[1]=Objet_SCSA.h;
    scsa_parmter[2]=Objet_SCSA.fe;
    scsa_parmter[3]=Objet_SCSA.gm;
    scsa_parmter[4]=Objet_SCSA.d;
    
    if(!writeBuffer(&Objet_SCSA,5,scsa_parmter,"scsa_parameters.dat")) return -1;
    
    if(!delta(Objet_SCSA.x_dim, deltaBuffer, Objet_SCSA.fe, feh)) return -1;
    cout<<" --> Delta matrix has been generated."<<endl;
    cout<<" --> Delta Matrix"<<endl;
    //EX Disp_matrx(Objet_SCSA.x_dim,Objet_SCSA.y_dim,deltaBuffer);
    
    
    /*            TEST the code
     
     */  //#################################################################################################################################
    
    
    float h=Objet_SCSA.h,gm = Objet_SCSA.gm,fe = Objet_SCSA.fe, h2 = h*h,d;
    int N = Objet_SCSA.x_dim,M = Objet_SCSA.y_dim, N2 = N*M, lda = N;//, i,j,k;
    
    if(Objet_SCSA.verbose) printf("allocating memory...\n");
    
    
    
    
    double comp_time0 = 0.0,time_eig=0.0,time_Psinnor=0.0, time_reconst=0.0,comp_end=0.0;
    
    
        cout<<endl<<endl<<"***********************  SCSA process has started  **********************"<< endl;

        
    
    if(Objet_SCSA.verbose) cout<<" --> The SCSA process has started. Please, Wait few seconds! : "<<endl<<endl;
    
    
    
    //*****************************************************************************************
    
    
    //M2
    //M2 % = = = = = =   The SCSA Method
    //M2 V = img;
    //M2 n = size(V,1); fe = 1; feh = 2*pi/n;
    //M2 h = 0.2550; gm = 1;
    //M2 UC = (1/(4*pi))*gamma(gm+1)/gamma(gm+2);
    //M2 h2L = h^2/UC;
    //M2
    
    fe=1,feh=2.0*PI / N;
    h=0.2550, gm = 1;
    float UC = (1.0/(4.0*PI))*tgamma(gm+1.0)/tgamma(gm+2.0);
    float h2L = (h*h)/UC;
    
   
    //M2 D1 = Delta_1D(n,fe,feh);
    // already computed and stored in Var "D"
    
    //M2
    //M2 I = eye(n);
    
    
    float I[N*N];
    
    Matrx_Unit( N,M, I);
    
    cout<<endl<<" --> Unity Matrix OK!"<<endl;
    
    //EX     Disp_matrx( N,M, I);
    
    
    //M2 L = sparse(n*n,n*n);         % Reduce the memory starage
    //M2 L = kron(I,D1) + kron(D1,I); % The 2D Laplacian operator
    //M2
    
    
    float Krn_prod1[N2*N2],Krn_prod2[N2*N2];
    kron_prod (Krn_prod1,I , N, N,  deltaBuffer, N, N);
    
    cout<<endl<<" --> Krn_prod1 Matrix OK!"<<endl;
    //EX Disp_matrx( N2,N2, Krn_prod1);
    
    kron_prod (Krn_prod2,deltaBuffer , N, N,  I, N, N);
    
    cout<<endl<<" --> Krn_prod2 Matrix OK!"<<endl;
    //EX Disp_matrx( N2,N2, Krn_prod2);
    
    //M2 V = V(:) ;
    //M2 SC = -h*h*L-diag(V); % The 2D Schr\"odinger operator
    //M2
    
    float SC_hhD[N2*N2],max_img;
    int NZ;
    
    max_img=SC_Sum(h,N2,Krn_prod1,Krn_prod2,matBuffer,SC_hhD,&NZ);

     cout<<endl<<endl<<"The number of NON zeros of SC_hhD matrix is   = "<<NZ<< " out of "<< N2*N2<<"  = "<<100-(100*NZ/(N2*N2)) <<" % of  Sparsity."<<endl<<endl;
    
  
    cout<<endl<<" --> SC_hhD Matrix OK!"<<endl;
     Disp_matrx( N2,N2, SC_hhD);                            // SC_hhD=SC mtrix
    
    //M2 tic
    comp_time0 = gettime();
    
    //M2
    //M2  [psi,lambda] = eig(SC); % Eigenvalues & eigenfunction of Schr\"odinger operator
    
        
    cout<<endl<<endl<<"*******************  Converting SC_hhD Matrix to CSR Sparse format   *******************"<< endl;
   
    int row_count= N2;
    int row_indices[N2];
    float values[NZ],val;
    int column_indices[NZ];   
// struct csr SC_hhD_csr;

size_t pair_index = 0;

for (int row_index = 0; row_index < N2; row_index++) {
    for (int column_index = 0; column_index < N2; column_index++) {
        
        val=SC_hhD[column_index+(N2*row_index)];
        
        if (val != 0.0) {
            values[pair_index] = val;
            column_indices[pair_index] = column_index;
            pair_index++;
        }
    }
     row_indices[row_index] = pair_index;
} 



cout<<endl<<endl<<"*****************   SC_hhD Matrix: Display CSR Sparse format OK !!  *******************"<< endl;

int z=0;

for(int j=0;j<N2;j++) {
    
    for(int i=0;i<row_indices[j]-z;i++) {
       cout<<endl<<"("<<j+1 <<","<<column_indices[i+z]+1<< ")="<<values[i+z] ;
       
     }
   z=row_indices[j];
  }

cout<<endl<<endl<<"*****************   SC_hhD Matrix: Display CSR Sparse format OK11  *******************"<< endl;






// 
//     cout<<endl<<endl<<"*******************  Eigen Analysis of SC_hhD Matrix  *******************"<< endl;
//     
//     
//     int N4=N2*N2, lwork = 1 + 6*N2 + 2*N4, liwork = 3 + 5*N2;
//     float lamda[N2];//, lamdai[n];
//     float work[lwork];
//     int iwork[liwork], info;
//     int Nh_size = 0;
//     
//     
//     memset(lamda, 0, N2*sizeof(float));
//     // memset(work, 0, N2*N2*sizeof(float));
//     
//     
//     // computes all eigenvalues and, optionally, eigenvectors of a
//     // real symmetric matrix SC  when its Lower triangle  is stored.
//     
//     syevd( 'V', 'L',
//           N2,
//           SC_hhD, N2, lamda,
//           work, lwork, iwork, liwork, info );
//     
//     if (info == 0)
// //         cout<<endl<<" The Eigenvalues and their corresponsing  orthonormal eigenvectors are computed   successfully of SC_hhD "<<endl<<endl;
//     
//     cout<<endl<<" --> All Eigen values  vector OK!"<<endl<<endl;
// //     Disp_EigenValues( N2, lamda);
//     
//     
//     
//     //M2  time_eig = toc;
//     time_eig = gettime() - comp_time0;
//     
//     
//     //M2
//     //M2  tic
//     
//     cout<<endl<<endl<<"*********************  EigenFunctions Normalization  ********************"<< endl;
// 
//     
//     comp_time0 = gettime();
//     
//     //M2  % Negative eigenvalues
//     //M2  temp = diag(lambda);
//     //M2  ind = find(temp<0);
//     
//     
//     //M2  kappa = diag((-temp(ind)).^(gm));
//     //M2  Nh = length(kappa);
//     
//     //M2
//     //M2  % The associated $L^2$-normalized eigenfunctions.
//     //M2  psin = psi(:,ind(:,1));
//     
//     float INDX[N2], KAPPA[N2];
//     
//     
//     Nh_size = 0;
//     
//     memset(INDX , 0, N2*sizeof(float));
//     memset(KAPPA, 0, N2*sizeof(float));
//     
//     
//     
//     for (int j=0;j<N2;j++)
//     {
//         
//         if (lamda[j] < 0)
//         {
//             
//             KAPPA[Nh_size]=ipow(-lamda[j], gm);
//             INDX[Nh_size]=j;
//             Nh_size++;
//         }
//         
//     }
//     cout<<endl<<" --> Negative Eigen  values  vector  OK!";
// //            Disp_EigenValues( Nh_size, KAPPA);
//     
// //     cout<<endl<<endl<<" --> Index of Negative Eigen  values  vector ";
// //            Disp_EigenValues( Nh_size, INDX);
//     
//     
//     cout<<endl<<"----> Number eigen = "<<Nh_size<<endl;
//     
//     
//     
//     float  psin[N2*Nh_size];
//     
//     memset(psin , 0, N2*Nh_size*sizeof(float));
//     
//     for (int i=0;i<N2;i++){
//         
//         for (int j=0;j<Nh_size;j++){
//             
//             int next_psin=i + INDX[j]*N2;
//             
//             psin[i + j*N2]=SC_hhD[next_psin];   // Compute its square
//             
//         }
//         
//     }
//     
//     
//     cout<<endl<<endl<<" --> Psin square Matrix : Eigen functions Matrix OK! "<<endl;
//     
//     //EX    Disp_matrx( N2,Nh_size, psin);
//     
//     
//     //M2  psinnor = sparse(n*n,Nh);
//     //M2  parfor j = 1:Nh
//     //M2  %     Nh-j
//     //M2      I = sqrt((simp(psin(:,j).^2,fe))^(-1));
//     //M2      psinnor(:,j) = (psin(:,j).*I).^2;
//     //M2  end
//     
//     
//     float  PSINNOR[N2*Nh_size];
//     
//     
//     for(int j = 0; j < Nh_size; j++){
//         
//         float I = 1.0/sqrt(simp3(psin+j*N2, N2, fe));
//         
//         for(int i = 0; i < N2; i++){
//             
//             int next_psin=i + INDX[j]*N2;
//             
//             PSINNOR[i + j*N2]= ipow((SC_hhD[next_psin]*I),2);
//             //D            cout<<endl<<endl<<"PSINNOR["<<i + j*N2<<"]="<< PSINNOR[i + j*N2]<< "   # I="<< I<< " Psin : "<< psin[i + j*N2]<<endl;
//         }
//     }
//     
//     
//     //D    cout<<endl<<endl<<" --> PSINNOR Matrix"<<endl;
//     
//     //EX    Disp_matrx( N2,Nh_size, PSINNOR);
//     
//     
//     time_Psinnor = gettime() - comp_time0;
//      //EX
//     
//     //M2
//     //M2  tic
//     
//     cout<<endl<<endl<<"************************  Image Reconstruction  *************************"<< endl;
//     
//     comp_time0 = gettime();
//     //M2  V1 = (h2L*sum(psinnor*kappa,2)).^(1/(1+gm));
//     
//     
//     float V1[N2],ERR[N2],reconst_img,MSE0=0.0,PSNR0=0.0,MSE=0.0,PSNR=0.0;
//     
//     //  memset(V1 , 0, N2*sizeof(float));
//     
//     for(int i = 0; i < N2; i++){
//         reconst_img=0.0;
//         
//         for(int j = 0; j < Nh_size; j++){
//             
//             //D               cout<<endl<<endl<<"PSINNOR["<<i + j*N2<<"]="<< PSINNOR[i + j*N2]<< "  * Kapa["<<j<<"] =:"<<KAPPA[j]<<endl;
//             
//             reconst_img+=PSINNOR[i + j*N2]*KAPPA[j];
//             
//             
//         }
//         //D            cout<<endl<<endl<<"1/(1+gm)="<<1/(1+gm)<<endl;
//         //D           cout<<endl<<endl<<"reconst_img="<<reconst_img<<endl;
//         //D           cout<<endl<<endl<<"max_img="<<max_img<<endl;
//         
//         
//         
//         V1[i]=powf(h2L*reconst_img,(1/(1+gm)));
//         
//         ERR[i]=((abs(matBuffer[i]-V1[i]))/max_img)*100.0;
//         
//         MSE0 += (matBuffer[i]-Image_ref[i])*(matBuffer[i]-Image_ref[i]);
//         MSE += (Image_ref[i]-V1[i])*(Image_ref[i]-V1[i]);
//         
//         
//         
//         
//         //D           cout<<endl<<endl<<"V1["<<i<<"]="<<V1[i]<<endl;
//     }
//     
//     // Evaliation PSNR Noisy
//     
//     MSE0=MSE0/N2;
//     PSNR0 = 10*log10(1.0/MSE0);
//     
//     // Evaliation PSNR Denoised
//     
//     MSE=MSE/N2;
//     PSNR = 10*log10(1.0/MSE);    
//     
//     //M2  time_sum = toc;
//     //M2
//     //M2  %Reshape to 2D...
//     //M2  tic
//     
//     comp_time0 = gettime();
//     //M2  V2 = zeros(n,n);
//     //M2  parfor i = 1:n
//     //M2      for j = 1:n
//     //M2          V2(j,i) = V1((i-1)*n+j,1);
//     //M2      end
//     //M2  end
//     //M2  time_reshape = toc;
//     //M2  img
//     //M2  Budder_img=V'
//     //M2  SCSA_img=V2
//     
//     //M2  ERR =(abs(img-V2))./max(max(img)).*100
//     //M2  MSE = mean2((img - V2).^2);
//     //M2  PSNR = 10*log10(1/MSE);
//     //M2
//     //M2  time_all = toc;
//     //M2  psnr_msg=strcat(' MSE =',num2str(MSE),' PSNR =   ',num2str(PSNR))
//     
//     
//     time_reconst = gettime() - comp_time0;
//     
//     comp_end = time_eig + time_Psinnor + time_reconst;
//     
//     cout<<endl<<endl<<" --> Reconstructed image Matrix OK!"<<endl;
//     
//     //EX  Disp_matrx( N,M, V1);
//     
//     //D1   cout<<endl<<endl<<" --> Original  image Matrix"<<endl;
//     
//     //D1   Disp_matrx(Objet_SCSA.x_dim,Objet_SCSA.y_dim,matBuffer);
//     
//     
//     //D1   cout<<endl<<endl<<" --> Error image Matrix"<<endl;
//     
//     //D1  Disp_matrx( N,M, ERR);
//     
//     
//     
//     
//     
//     
//     
//     //#################################################################################################################################
//     
//     //  End TEST the Code
//     
//     
//     
//     
//     
//     //if(!process(&Objet_SCSA, matBuffer, deltaBuffer)) return -1;
//     //cout<<endl<<endl;
//     
//     cout<<endl<<endl<<"************************   2D2D SCSA Diagnosis   ************************"<<endl;
// 
//     cout<<" The computations are done with the following results :  "<< endl;
//     cout<< "==> Performances  :"<<endl;
//     cout<<"Original:   MSE = "<<MSE0<<  "  PSNR = "<<PSNR0<<endl;
//     cout<<"Denoised:   MSE = "<<MSE<<  "  PSNR = "<<PSNR<<endl<< endl;
//     cout<< "==> Execution Time:   Totale Time  = "<<comp_end<<" sec"<< endl;
//     cout<< "EigenAnalysis = "<<100.0*time_eig/comp_end<< "%  "<<endl;
//     cout<<"EigenFunction normalization = "<<100.0*time_Psinnor/comp_end<< "%  "<<endl;
//     cout<<"Reconstruction  = "<<100.0*time_reconst/comp_end<< " % "<<endl<<endl;
//     
//     if(!writeBuffer(&Objet_SCSA,Objet_SCSA.x_dim*Objet_SCSA.x_dim,V1,"scsa_output.dat")) return -1;
//     
    cout<<endl<<"****************************     End of SCSA process    ***********************"<<endl;
  
    
    delete matBuffer;
    delete deltaBuffer;
    
    return 0;
}

// *********************** FUNCTION ROUTINES   ***********************

/*=========================== 1D SCSA PROCESS   =============================
 
 ___________________________________________________________________________
 | This function returns 1D SCSA PROCESS with paramters stored in  Objet_SCSA|
 | _________________________________________________________________________ |*/

bool process(Class_SCSA* Objet_SCSA, float* V, float* D){
    float fe = Objet_SCSA->fe, feh = 2.0*PI / Objet_SCSA->x_dim, h2 = Objet_SCSA->h*Objet_SCSA->h,d;
    int n = Objet_SCSA->x_dim, n2 = n*n, lda = n;//, i,j,k;
    
    if(Objet_SCSA->verbose) printf("allocating memory...\n");
    
    float PSINNORX[n2*n], PSINNORY[n2*n];
    float KAPPAX[n2], KAPPAY[n2];
    int NX[n], NY[n];
    
    
    int lwork = 1 + 6*n + 2*n2, liwork = 3 + 5*n;
    float SC[n2];
    float lamda[n];//, lamdai[n];
    float work[lwork], psin[n2];
    int iwork[liwork], info;
    int Nh_size = 0;
    float SC_hhD[n2];
    
    double comp_time = 0.0, eigen_time = 0.0, gemv_time = 0.0, cur_time;
    
    
    //compute L
    //M:   L = 2^(-d)*pi^(-d/2)*gamma(gm+1)/gamma(gm+1+(d/2)); % la constante universelle
    float L = ipow(4.0*PI, Objet_SCSA->d / 2);
    for(int k = Objet_SCSA->d / 2; k >= 1; k--){
        L *= Objet_SCSA->gm+k;
    }
    L = 1.0 / L;
    
    if(Objet_SCSA->verbose) printf("starting first loop... Begin, please wait ... :) \n");
    
    comp_time = gettime();
    
    memset(KAPPAX, 0, n2*sizeof(float));
    memset(KAPPAY, 0, n2*sizeof(float));
    
    
    memcpy(SC_hhD, D, n2*sizeof(float));
    for(int j = 0; j < n2; j++)
        SC_hhD[j] *= -h2;
    
    int cur = 0;
    if(Objet_SCSA->verbose) printf("iter    ");
    for(int i = 0; i < n; i++){
        cout<<".";
        if(Objet_SCSA->verbose){ printf("\b\b\b\b%4d", cur++); fflush( stdout );}
        //rows
        
        //M: zx = 0.5*V(i,:);
        //M: Vx=diag(zx);
        //M: SCx=-h*h*D-Vx; % Schr\"odinger operator
        
        memcpy(SC, SC_hhD, n2*sizeof(float));
        for(int j = 0; j < n; j++)
            SC[j + j*n] -= 0.5 * V[i + j*n];
        
        //M: [psix,lamdax]=eig(SCx);% Eigenvalues & eigenfunction of Schr\"odinger operator
        cur_time = gettime();
        
        // computes all eigenvalues and, optionally, eigenvectors of a
        // real symmetric matrix SC  when its Lower triangle  is stored.
        syevd( 'V', 'L',
              n,
              SC, n, lamda,
              work, lwork, iwork, liwork, info );
        eigen_time += gettime() - cur_time;
        
        //M:  % Negative eigenvalues
        //M:  tempx = diag(lamdax);
        //M:  indx = find(tempx<0);
        Nh_size = 0;
        while(lamda[Nh_size++] < 0);
        //M:  temp2x = tempx(indx);
        //M:  kappax = diag(sqrt(-temp2x));
        //we will not store temp2x and kappax, instead computed directly in Kappax
        
        //M:  % The associated $L^2$-normalized eigenfunctions.
        //M:  psinx = psix(:,indx(:,1));
        //M:  Ix= simp(psinx.^2,fe);
        //M:  psinnorx=psinx./sqrt(Ix);
        //M:  Kappax = diag(kappax);
        //M:  Nx = length(Kappax);
        //M:  NX(i) = Nx;
        //M:  KAPPAX(i,1:Nx) = Kappax';
        //M:  PSINNORX(1+n*(i-1):n*i,1:Nx) = psinnorx;
        
        int psin_size = n*Nh_size;
        //psin = new float[psin_size];
        for(int j = 0; j < Nh_size; j++){
            memcpy(psin+j*n, SC+j*n, n*sizeof(float));
            //memcpy(psin+j*n, psi+indx[j]*n, n*sizeof(float));
        }
        //writeBuffer(Objet_SCSA, psin_size, psin, string("psin128.dat"));return 0;
        //for(j = 0; j < psin_size; j++)
        //  psin[j] *= -1;
        //printf(" %f", psin[j]);
        //printf("\nI: %.15f\n", I);return 0;
        
        
        NX[i] = Nh_size;
        
        for(int j = 0; j < NX[i]; j++){
            KAPPAX[i + j*n] = -lamda[j];//sqrt(-lamda[indx[j]]);// redundant, need square later
        }
        
        for(int k = 0; k < NX[i]; k++){
            float I = simp2(Objet_SCSA,psin+k*n, n, fe);//sqrt(simp2(psin, psin_size, fe));//
            for(int j = 0; j < n; j++){
                d = psin[j + k*n]*psin[j + k*n] / I;
                //d = pow(psin[j + k*n] / I,2.0);
                PSINNORX[n2*i + j + k*n] = d;
            }
        }
        
        //M:  %columns
        //M:  zy = 0.5*V(:,i);
        //M:  Vy = diag(zy);
        //M:  SCy=-h*h*D-Vy; % Schr\"odinger operator
        memcpy(SC, SC_hhD, n2*sizeof(float));
        for(int j = 0; j < n; j++)
            SC[j + j*n] -= 0.5 * V[j + i*n];
        //M:  [psiy,lamday]=eig(SCy); % Eigenvalues & eigenfunction of Schr\"odinger operator
        cur_time = gettime();
        syevd( 'V', 'L',
              n,
              SC, n, lamda,
              work, lwork, iwork, liwork, info );
        eigen_time += gettime() - cur_time;
        
        //M:  % Negative eigenvalues
        //M:  tempy = diag(lamday);
        //M:  indy = find(tempy<0);
        Nh_size = 0;
        while(lamda[Nh_size++] < 0);
        //M:  temp2y = tempy(indy);
        //M:  kappay = diag(sqrt(-temp2y));
        
        //M:  % The associated $L^2$-normalized eigenfunctions.
        //M:  psiny = psiy(:,indy(:,1));
        //M:  Iy= simp(psiny.^2,fe);
        //M:  psinnory = psiny./sqrt(Iy);
        //M:  Kappay = diag(kappay);
        //M:  Ny = length(Kappay);
        
        //M:  NY(i) = Ny;
        //M:  KAPPAY(i,1:Ny) = Kappay';
        //M:  PSINNORY(1+n*(i-1):n*i,1:Ny) = psinnory;
        psin_size = n*Nh_size;
        for(int j = 0; j < Nh_size; j++){
            memcpy(psin+j*n, SC+j*n, n*sizeof(float));
        }
        
        
        NY[i] = Nh_size;
        
        for(int j = 0; j < NY[i]; j++){
            KAPPAY[i + j*n] = -lamda[j];//sqrt(-lamda[indx[j]]);// redundant, need square later
        }
        
        for(int k = 0; k < NY[i]; k++){
            float I = simp2(Objet_SCSA,psin+k*n, n, fe);//sqrt(simp2(psin, psin_size, fe));//
            for(int j = 0; j < n; j++){
                d = psin[j + k*n]*psin[j + k*n] / I;
                //d = pow(psin[j + k*n] / I,2.0);
                PSINNORY[n2*i + j + k*n] = d;
            }
        }
        
    }
    
    
    if(Objet_SCSA->verbose) printf(" done...\nstarting second loop... Construction of image. Please wait... :) \n");
    //M:  V1 = zeros(n,n);
    //M:  for i = 1 :n
    //M:    etape = i;
    //M:    for j = 1: n
    //M:      %tic
    //M:      Kap = (kron((KAPPAX(i,1:NX(i)).^2)',ones(1,NY(j))) + kron((KAPPAY(j,1:NY(j)).^2),ones(NX(i),1))).^(gm);
    //M:      %toc
    //M:      %tic
    //M:      V1(i,j) = V1(i,j) +(h^2/L)*(PSINNORX(j+(i-1)*n,1:NX(i)).^2)*Kap*(PSINNORY(i+(j-1)*n,1:NY(j)).^2)';
    //M:      %toc
    //M:    end
    //M:  end
    //M:  V2 = zeros(n,n);
    //M:  V2 = (V1.^(2/(2*gm+d)));
    //M:  ERR =(abs(V-V2))./max(max(V)); % Relatif error
    //M:  mse = mean2((V - V2).^2);
    //M:  psnr = 10*log10(1/mse);
    
    float V1[n2];
    float Kap[n2];
    float v[n];
    float alpha = 1.0, beta = 0.0;
    int incv = 1;
    float p = 2.0/(2.0*Objet_SCSA->gm+Objet_SCSA->d), mse = 0.0,psnr, h2_L = h2 / L;
    
    try{
        
        if(Objet_SCSA->verbose) printf("%%        ");
        memset(V1, 0, n2*sizeof(float));
        
        for(int i = 0; i < n; i++){
            cout<<".";
            
            for(int j = 0; j < n; j++){
                memset(Kap, 0, n2*sizeof(float));
                
                kron(Kap, n, KAPPAX, i, KAPPAY, j, NX[i], NY[j], Objet_SCSA->gm);
                
                memset(v, 0, n*sizeof(float));
                cur_time = gettime();
                gemv('N',
                     NX[i], NY[j],
                     alpha,
                     Kap, NX[i],
                     PSINNORY+j*n2+i, n,
                     beta,
                     v, incv );
                gemv_time += gettime() - cur_time;
                
                V1[i + j*n] = h2_L * dot(NX[i], PSINNORX+i*n2+j, n, v, incv);
                
                //cout<< "("<<V[i + j*n]<<","<<V1[i + j*n]<<") ";
                
                V1[i + j*n] = pow(V1[i + j*n], p);
                
                mse += square(V[i + j*n] - V1[i + j*n]);
               
            }
        }
        
        mse /= n2;
        psnr = 10.0* log10(1.0/mse);
        comp_time = gettime() - comp_time;
        
    }catch(...){
        printf("caught exception ");
    }
    printf("\ncomputation done\nmse: %f, psnr: %f\nelapsed time: %fs, eigenAnalysis time %f%%, gemv time %f%%\n", mse, psnr, comp_time, 100*eigen_time/comp_time, 100*gemv_time/comp_time);
    
    // chahidd added line
    memcpy(V,V1, n2*sizeof(float));
    
    // end
    
    return 1;
}

/*======================== Kronecker product   ===================
 __________________________________________________________________
 | This function returns the Kronecker product of KAPX AND KAPY     |
 | ________________________________________________________________ |*/

void kron(float* kap, int n, float* KAPX, int i, float* KAPY, int j, int rows, int cols, int gm){
    for(int r = 0; r < rows; r++){
        for(int c = 0; c < cols; c++){
            float v = KAPX[i+r*n]+KAPY[j+c*n];
            kap[r + c*rows] = v;
            for(int q = 1; q < gm; q++)
                kap[r + c*rows] *= v;
        }
    }
}


/*============================= SIMPEOMS'S RULE  ============================/*
 ___________________________________________________________________________
 | This function returns the numerical integration of a function f using     |
 | Simpson method ot compute the  associated  L^2 -normalized eigenfunctions.|
 | _________________________________________________________________________ |*/

float simp2(Class_SCSA* Objet_SCSA, float* f, int n, float dx){
    //M:  % Author: Taous Meriem Laleg
    //M:  %  This function returns the numerical integration of a function f
    //M:  %  using the Simpson method
    
    //M:  n=length(f);
    //M:  I(1)=1/3*f(1)*dx;
    //M:  I(2)=1/3*(f(1)+f(2))*dx;
    
    //M:  for i=3:n
    //M:    if(mod(i,2)==0)
    //M:      I(i)=I(i-1)+(1/3*f(i)+1/3*f(i-1))*dx;
    //M:    else
    //M:      I(i)=I(i-1)+(1/3*f(i)+f(i-1))*dx;
    //M:    end
    //M:  end
    //M:  y=I(n);
    float I;//[2];
    I = (sqr(f[0])+sqr(f[1]))*dx / 3.0;
    
    for(int i = 2; i < n; i++){
        I += sqr(f[i])*dx/3.0 + sqr(f[i-1])*dx*(i%2?1.0/3.0:1.0);   // short if syntax :condition ? "YES" : "NO";
        
        
    }
    return I;
}


/*============================= DELTA MATRIX   ==================================
 ____________________________________________________________________________
 | This function returns D matrix, where deltaBuffer is a second order        |
 | differentiation matrix obtained by using the Fourier pseudospectral mehtod |
 | __________________________________________________________________________ |*/

bool delta(int n, float* &deltaBuffer, float fex, float feh){
    int ex, p;//float ex[n-1];
    float dx, test_bx[n-1], test_tx[n-1], factor = feh/fex;
    factor *= factor;

    if(n%2 == 0){
        p = 1;
        dx = -(PI*PI)/(3.0*feh*feh)-1.0/6.0;
        for(int i = 0; i < n-1; i+=2){
            ex = n-i-1;
            p *= -1;
            test_bx[i] = test_tx[i] = -0.5 * p / square(sin( ex * feh * 0.5));
            ex = n-i-2;
            p *= -1;
            test_bx[i+1] = test_tx[i+1] = -0.5 * p / square(sin( ex * feh * 0.5));
        }
    }else{
        dx = -(PI*PI) / (3.0*feh*feh) - 1.0/12.0;
        for(int i = 0; i < n-1; i++){
            ex = n-i-1;
            test_bx[i] = -0.5 * pow(-1,  ex) * cot( ex * feh * 0.5) / (sin( ex * feh * 0.5));
            test_tx[i] = -0.5 * pow(-1, -ex) * cot(-ex * feh * 0.5) / (sin(-ex * feh * 0.5));
            
            //$            test_bx[i] = -0.5 * pow(-1,  ex) * cos( ex * feh * 0.5) / (sin( ex * feh * 0.5));
            //$            test_tx[i] = -0.5 * pow(-1, -ex) * cos(-ex * feh * 0.5) / (sin(-ex * feh * 0.5));
        }
    }
    
    unsigned long buffer_size = n * n;
    deltaBuffer = new float[ buffer_size ];
    if(!deltaBuffer)
    {
        cout << "out of memory, could not allocate "<< buffer_size <<" of memory!" << endl;
        return false;
    }
    
    int lda = n+1;
    
    for(int r = 0; r < n; r++){
        deltaBuffer[r*lda] = dx * factor;
    }
    float vL, vU;
    for(int r = 1; r < n; r++){
        vL = test_bx[n-r-1] * factor;
        vU = test_tx[n-r-1] * factor;
        
        for(int c = 0; c < n-r; c++){
            deltaBuffer[r   + c*lda] = vL;
            deltaBuffer[r*n + c*lda] = vU;
        }
    }
    
    return true;
}

// *********************** functions for BLAS  ***********************


/*====================  EIGENVALUES DECOMPOSITION =============================
 __________________________________________________________________________________
 | This function computes all eigenvalues and, optionally, eigenvectors of :        |
 |  -> "a" real symmetric matrix of dmnsn "lda" with Lower triangle  is stored.     |
 |  -> If INFO = 0, "W" contains eigenvalues in ascending order.                    |
 |  -> If JOBZ = 'V', then if INFO = 0,A contains the orthonormal eigenvectors of A |
 |  -> if INFO = 0, WORK(1) returns the optimal LWORK                               |
 |  -> If JOBZ = 'V' and N > 1, LWORK must be at least:  1 + 6*N + 2*N**2.          |
 |  -> If JOBZ  = 'V' and N > 1, LIWORK must be at least 3 + 5*N.                   |
 |  -> INFO is INTEGER                                                              |
 |     = 0:  successful exit                                                        |
 |     < 0:  if INFO = -i, the i-th argument had an illegal value                   |
 |     > 0:  if INFO = i and JOBZ = 'N', then the algorithm failed                  |
 |              to converge; i off-diagonal elements of an intermediate tridiagonal |
 |              form did not converge to zero;                                      |
 |             if INFO = i and JOBZ = 'V', then the algorithm failed to compute an  |
 |               eigenvalue while working on the submatrix lying in rows and columns|
 |               INFO/(N+1) through  mod(INFO,N+1).                                 |
 | ________________________________________________________________________________ |*/

void syevd( const char jobz, const char uplo,
           const int n,
           float* a, const int lda, float* w,
           float* work, const int lwork, int* iwork, const int liwork, int info ){
    
    
    cout<<endl<<endl<<" --> Eigen Analysis of the Matrix SC_hhD . "<<endl;
    
    ssyevd( &jobz, &uplo,
           &n,
           a, &lda, w,
           work, &lwork, iwork, &liwork, &info );
    
}


/*================================== gemv   ==================================
 ____________________________________________________________________________
 |       This function performs one of the matrix-vector operations           |
 |                  y := alpha*A*x + beta*y if transa='N'                     |
 | __________________________________________________________________________ |*/

void gemv( const char transa,
          const int m, const int n,
          const float alpha,
          const float *A, const int lda,
          const float *x, const int incx,
          const float beta,
          float *y, const int incy ){
    
    
    
    sgemv(&transa,
          &m, &n,
          &alpha,
          A, &lda,
          x, &incx,
          &beta,
          y, &incy );
    
    //$    cout<<" The matrix-vector has not been performed ( just for test)" <<endl;
    
    
}


/*================================== DOT   ==================================
 ____________________________________________________________________________
 |       This function forms the dot product of two vectors X and Y.          |
 | __________________________________________________________________________ |*/

float  dot(const int N, const float  *X, const int incX,
           const float  *Y, const int incY){
    return sdot(&N, X, &incX,Y, &incY);
    
    //$    cout<<" The dot product has not been performed ( just for test)" <<endl;
    //$    return *X;
}


/*================================ READ DATA    ===============================
 ____________________________________________________________________________
 |         This function  reads the ".dat" file stored in Objet_SCSA          |
 |                  to the buffer (table Pointer )  matBuffer                 |
 | __________________________________________________________________________ |*/


bool readInput(Class_SCSA* Objet_SCSA, float* &matBuffer, float* &original)//, float* &deltaBuffer)
{
    if(Objet_SCSA->verbose) cout << "reading data from file: " << Objet_SCSA->dataFileName << ", data of size: " << Objet_SCSA->x_dim << "x" << Objet_SCSA->y_dim << endl;
    FILE* infile;
    
    // load Noisy Image
    
    cout<<endl<<"   --> Noisy Image : "<< Objet_SCSA->dataFileName.c_str();
    infile = fopen(Objet_SCSA->dataFileName.c_str(), "rb");
    if(!infile)
    {
        cout << "could not open input file!" << endl; return 0;
    }
    
    Objet_SCSA->buffer_size = Objet_SCSA->x_dim * Objet_SCSA->y_dim;
    
    if(Objet_SCSA->verbose) cout << "reading buffer of size: " << Objet_SCSA->buffer_size << endl;
    matBuffer = new float[ Objet_SCSA->buffer_size ];
    if(!matBuffer)
    {
        cout << "out of memory, could not allocate "<< Objet_SCSA->buffer_size <<" of memory!" << endl;
        fclose(infile);
        return false;
    }
    unsigned long res = fread((void*)matBuffer, sizeof(float), Objet_SCSA->buffer_size, infile);
    if(ferror(infile)){
        cout << "error reading file!" << endl;
    }
    if(Objet_SCSA->verbose) cout << "did read " << res << " entries, content not checked though!" << endl;
    fclose(infile);
    
        // load Original Image 
    
    cout<<endl<<"   --> Reference Image :  "<< Objet_SCSA->originImage.c_str()<<endl;
    infile = fopen(Objet_SCSA->originImage.c_str(), "rb");
    if(!infile)
    {
        cout << "could not open input file!" << endl; return 0;
    }
    
    Objet_SCSA->buffer_size = Objet_SCSA->x_dim * Objet_SCSA->y_dim;
    
    if(Objet_SCSA->verbose) cout << "reading buffer of size: " << Objet_SCSA->buffer_size << endl;
    original = new float[ Objet_SCSA->buffer_size ];
    if(!original)
    {
        cout << "out of memory, could not allocate "<< Objet_SCSA->buffer_size <<" of memory!" << endl;
        fclose(infile);
        return false;
    }
    unsigned long res2 = fread((void*)original, sizeof(float), Objet_SCSA->buffer_size, infile);
    if(ferror(infile)){
        cout << "error reading file!" << endl;
    }
    if(Objet_SCSA->verbose) cout << "did read " << res2 << " entries, content not checked though!" << endl;
    fclose(infile);
    
    return true;
}


/*========================= WRITE results  DATA    ===========================
 ____________________________________________________________________________
 |       This function writes the the buffer (table Pointer )  buffer         |
 |                   to  "fileName.dat" of Objet_SCSA                         |
 | __________________________________________________________________________ |*/

bool writeBuffer(Class_SCSA* Objet_SCSA, long int size, float* buffer, string fileName)
{
    if(Objet_SCSA->verbose) cout << "writeing data to file: " << fileName << ", data of size: " << size << endl;
    FILE* outfile;
    //load matrix data
    outfile = fopen(fileName.c_str(), "wb");
    if(!outfile)
    {
        cout << "could not open output file!" << endl; return 0;
    }
    
    unsigned long res = fwrite((void*)buffer, sizeof(float), size, outfile);
    if(ferror(outfile)){
        cout << "error writing to file!" << endl;
        return 0;
    }
    fclose(outfile);
    
    cout<<" --> "<<fileName<<" has been created succefully."<<endl;
    return true;
}

/*===================== SCSA Object reconstruction     =======================
 ____________________________________________________________________________
 | This function contains the differents information of about the input data  |
 | to process, Moreover it stores also SCSA parameters to use in the Process  |
 |              All in type structure object called  Objet_SCSA               |
 | __________________________________________________________________________ |*/


int parse_Objet_SCSA( int argc, char** argv, Class_SCSA *Objet_SCSA )
{
    // fill in default values
    Objet_SCSA->x_dim = 64;
    Objet_SCSA->y_dim = 64;
    
    Objet_SCSA->d = 2;
    Objet_SCSA->h = 0.7;
    Objet_SCSA->gm = 1;
    Objet_SCSA->fe = 1.0;
    //Objet_SCSA->L = 0.015915494309190;
    Objet_SCSA->dataFileName = "scsa_input64.dat";
    Objet_SCSA->deltaFileName = "baboon_D.dat";
   Objet_SCSA->originImage = "scsa_original64.dat"; ;
    Objet_SCSA->jobvl = 'N';
    Objet_SCSA->jobvr = 'V';
    Objet_SCSA->verbose= false;
    
    int info;
    for( int i = 1; i < argc; ++i ) {
        // ----- matrix size
        // each -N fills in next entry of size
        if ( strcmp("-N", argv[i]) == 0 && i+1 < argc ) {
            i++;
            int m, n;
            info = sscanf( argv[i], "%d:%d", &m, &n);
            if ( info == 2 && m > 0 && n > 0 ) {
                Objet_SCSA->x_dim = m;
                Objet_SCSA->y_dim = n;
            }
            else if ( info == 1 && m >= 0 ) {
                Objet_SCSA->x_dim = m;
                Objet_SCSA->y_dim = m;// implicitly
            }
            else {
                fprintf( stderr, "error: -N %s is invalid; ensure m >= 0, n >= 0, info=%d, m=%d, n=%d.\n",
                        argv[i],info,m,n);
                exit(1);
            }
        }
        
        
        else if ( strcmp("--data", argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->dataFileName = argv[++i];
            Objet_SCSA->originImage = argv[++i];
        }
        else if ( strcmp("--delta", argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->deltaFileName = argv[++i];
        }
        else if ( strcmp("-d",    argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->d = atoi( argv[++i] );
        }
        else if ( strcmp("-h", argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->h = atof( argv[++i] );
        }
        else if ( strcmp("-fe", argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->fe = atof( argv[++i] );
        }
        else if ( strcmp("-gm",   argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->gm = atoi( argv[++i] );
            //Objet_SCSA->L = 1.0 / (4*PI*(Objet_SCSA->gm+1));
        }/*
          else if ( strcmp("-L", argv[i]) == 0 && i+1 < argc ) {
          Objet_SCSA->L = atof( argv[++i] );
          }*/
        else if ( strcmp("-v",  argv[i]) == 0 ) { Objet_SCSA->verbose= true;  }
        
        // ----- usage
        else if ( strcmp("--help", argv[i]) == 0 ) {
            USAGE
            exit(0);
        }
        else {
            fprintf( stderr, "error: unrecognized option %s\n", argv[i] );
            exit(1);
        }
    }
    
    return 1;
}


/*========================== Time measurement     ============================
 ____________________________________________________________________________
 |       This function returns the actual time in secondes                   |
 | __________________________________________________________________________ |*/

double gettime(void)
{
    struct timeval tp;
    gettimeofday( &tp, NULL );
    
    return tp.tv_sec + 1e-6 * tp.tv_usec;
}


// *********************** CHAHID FUNCTION ROUTINES   ***********************

/*======================== Kronecker product   ===================
 __________________________________________________________________
 | This function returns the Kronecker product of A AND B           |
 | ________________________________________________________________ |*/


void kron_prod (float* kprod,  float* a, int ma, int na,  float* b, int mb, int nb)
{
    int         i, j, k, l;
    int         np = na * nb;
    
    for (i = 0; i < ma; ++ i)
        for (j = 0; j < na; ++ j)
            for (k = 0; k < mb; ++ k)
                for (l = 0; l < nb; ++ l)
                    
                    //row= (i-1)*nb+l;
                    // col=(j-1)*mb+k;
                    
                    // slice_a=(j-1)*na+i;
                    //slice_b=(k-1)*nb+l;
                    
                    
                    //c((col-1)*na*nb+row)=a(slice_a)*b(slice_b);
                    
                    kprod[(j*mb+k)*na*nb+(i*nb+l)] = a[j*na+i] * b[k*nb+l];
    
}


/*======================== unity Matrix   ===================
 __________________________________________________________________
 |              This function returns unity Matrix                  |
 | ________________________________________________________________ |*/

void Matrx_Unit(int n,int m,float *Mtx_unit){
    
    memset(Mtx_unit, 0, n*m*sizeof(float));
    
    int n2=n*m,step=0;
    
    for (int j=0; j<n2; j+=n) {
        Mtx_unit [j+step]=1;
        step++;
    }
}

/*======================== SUM matrix   ===================
 __________________________________________________________________
 |  This function returns the sum of A and B matrix  Matrix        |
 |________________________________________________________________ |*/

float SC_Sum(float h, int n,float *D1,float *D2,float *V,float *SC,int *NZ) {
    
    int step=0,non_zero=0;
    float max_img0=0.0;
    cout<<endl<< "-h*h="<< -h*h<<endl;
    
    for (int j=0; j<n*n; j++) {
        
        SC[j]=(-h*h)*(D1[j]+D2[j]);
        
        if(SC[j]!=0.0){
            non_zero++;       // Non Zero element
        }
        
        //D         cout<<endl<< "| L = "<< D1[j]<<" + "<<D2[j];
        
        //D         cout<<endl<< "|"<< j<<"  "<<j%(n+1)<<" == "<<SC[j];
        
        if (j%(n+1)==0){
            
            SC[j]=SC[j]-V[step];
            
            max_img0=(V[step]>max_img0?V[step]:max_img0);
            
            //D            cout<<"- "<<V[step]<< "|";
            step++;
            
        }
        
        
    }
    *NZ=non_zero;
//     cout<<endl<<endl<<"The number of NON zeros of SC_hhD matrix is   = "<<non_zero<< " out of "<< n*n<<"  = "<<100-(100*non_zero/(n*n)) <<" % of  Sparsity."<<endl<<endl; 
    return max_img0;
    
}
/*======================== Displays   ===================
 __________________________________________________________________
 | This function Shows the buffer in  Matrix representation         |
 | ________________________________________________________________ |*/

void Disp_matrx(int n,int m,float *Mtx_A) {
//     cout<<endl<<" _______  Displaying Buffer :"<< n*m<<" Values __________"<<endl<<endl;
//     
//     for (int i=0; i<n*m; i++){
//         printf(" | %f | ",Mtx_A [i] );}
//     
    cout<<endl<<endl<<" __________  Displaying Matrix :"<< n<<"X"<<m<<" _____________"<<endl<<endl;
    
    for (int i=0; i<n; i++) {
        for (int j=0; j<m; j++) {
            
            printf(" | %f | ",Mtx_A [i+j*n] );
        }
        
        printf(" \n");}
    
}



/*======================== Displays   ===================
 __________________________________________________________________
 | This function Shows the buffer in  Matrix representation         |
 | ________________________________________________________________ |*/

void Disp_EigenValues(int n,float *Vector_A) {
    
    printf(" \n\n_______  Displaying Eigen Values  Vector  __________\n\n");
    
    for (int j=0; j<n; j++) {
        
        printf(" | %f | ",Vector_A[j] );
        
        
    }
    
    
    
}

/*=========================== 2D SCSA PROCESS   =============================
 
 ___________________________________________________________________________
 | This function returns 2D SCSA PROCESS with paramters stored in  Objet_SCSA|
 | _________________________________________________________________________ |
 
 THE ORIGINAL MATLAB CODE:
 %==========================================================================
 %     Recostruction of Lena's image using 2D SCSA formula without using
 % separation of variables for $h = ...$ and $\gamma=1$
 %
 % http://sipi.usc.edu/database/database
 %
 %   Author: Zineb Kaisserli and Meriem Laleg
 %    December 20th, 2014
 %==========================================================================*/

bool SCSA_2D2_full(Class_SCSA* Objet_SCSA, float* imag, float* Delta_mtrx){
    
    return 1;
}


/*======================= Display  Image information    =======================
 
 ___________________________________________________________________________
 |   This function displays the image information stored in  Objet_SCSA     |
 | _________________________________________________________________________|*/




bool display_Objet_SCSA( Class_SCSA *Objet_SCSA )
{
    cout<< " ============== Image Informations =============="<<endl;
    cout<< "|  Dimmension : " <<   Objet_SCSA->x_dim<<  " X "<<   Objet_SCSA->y_dim<< " Pixels."<<endl;
    //Objet_SCSA->L = 0.015915494309190;
    cout<< "|  Reference image   : "<<    Objet_SCSA->originImage <<" ."<<endl;
    cout<< "|  Input Noisy image : "<<    Objet_SCSA->dataFileName <<" ."<<endl;
    cout<< "|*************** SCSA Parameters *****************"<<endl;
    cout<< "| h== "<<Objet_SCSA->h << "    d="<< Objet_SCSA->d<< "    gm="<<Objet_SCSA->gm << "    fe="<<Objet_SCSA->fe << "."<<endl;
    cout<< "| jobvl= "<< Objet_SCSA->jobvl << "    jobvr="<< Objet_SCSA->jobvr<< "    verbose="<< Objet_SCSA->verbose<< "."<<endl;
    cout<< " ================================================="<<endl;
    return 1;
}



/*============================= SIMPEOMS'S RULE  ============================/*
 ___________________________________________________________________________
 | This function returns the numerical integration of a function f^2 using   |
 | Simpson method ot compute the  associated  L^2 -normalized eigenfunctions.|
 | _________________________________________________________________________ |*/


float simp3(float* f, int n, float dx){
    //M2      %  This function returns the numerical integration of a function f
    //M2      %  using the Simpson method
    //M2
    //M2      [n,~]=size(f);
    //M2      I=1/3*(f(1,:)+f(2,:))*dx;
    //M2
    //M2      for i=3:n
    //M2          if(mod(i,2)==0)
    //M2              I=I+(1/3*f(i,:)+1/3*f(i-1,:))*dx;
    //M2          else
    //M2              I=I+(1/3*f(i,:)+f(i-1,:))*dx;
    //M2          end
    //M2      end
    //M2      y=I;
    
    float I;
    I = (f[0]*f[0]+f[1]*f[1])*dx/3.0;
    
    for(int i = 2; i < n; i++){
        
        if (i % 2==0){
            I = I+(((1.0/3.0*f[i]*f[i])+f[i-1]*f[i-1])*dx);
            
        }
        
        else{
            I = I+(f[i]*f[i]+f[i-1]*f[i-1])*(dx/3.0);
            
        }
        
        
    }
    return I;
}















/*   Comment
 //EX  : displays during execution
 
 //D1  :
 
 
 */
