READ ME for scsa tool:

COMPILATION:
  To build this program's executable file, please follow following simple steps:

  - make sure you have intel compiler (icc) and intell MKL library installed on your environment, you can simply load these by typing:
    %>  module load intel/15
    in case a different intel compiler is loaded, please edit the make.inc file to reflect that

  - cd to code location
  - compile the code by typing:
    %> make
    


USAGE:
- for quick help on program parameters, type:
  %> ./scsa_d --help

- the program expects the image input to be provided in binary format file, to generate this file in Matlab, type the following in Matlab command:
  >> fileID = fopen('path/to/output/file','w');fwrite(fileID,your_image,'double');fclose(fileID);
  and specify the correct file name and path, also replace 'image_name' by your image matrix

- sample usage:
  - assume your image file has been saved in a binary file named "baboon.dat" as per previous step and image size is set to 256:
  - cd to your folder where the executable resides
  - type the following on the command line
    %> ./scsa_d --data baboon.dat -N 256

  - to change input parameters, type for example:
    %> ./scsa_d --data baboon.dat -N 256 -d 4 -h 0.4 -gm 6 -fe 2

    
IMPORTANT:
  - code assumes the 'gm' parameter is an integer value
  - code assumes 'd' parameter is an integer value divisible by 2


