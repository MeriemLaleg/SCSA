% IMPORTANT: do not run tthis code directly, run it from SCSA_prog to
% allocate data and read image

V = 0.5.*img;
n = size(V,1); fe = 1; feh = 2*pi/n;
h = 0.2;
gm = 4;
%gm1 = 4;
%L1 = (1/(4*pi))*gamma(gm1+1)/gamma(gm1+2); % la constante universelle
L = (1/(4*pi))/(gm+1); % la constante universelle
%L-L1
h2L = h^2/L;
D = delta(n,fe,feh);
D = -h*h*D;


disp('Begin for columns, please wait ... :)')
%t = cputime;
ts = tic;
for i = 1:n

    SCy = D-diag(V(:,i)); % Schr\"odinger operator
    [psiy,lamda]=eig(SCy); % Eigenvalues & eigenfunction of Schr\"odinger operator

    % Negative eigenvalues
    temp = diag(lamda);
    temp1 = temp(temp<0);
    Ny = length(temp1);
    KAPPAY(i,1:Ny) = -temp1;

    % The associated $L^2$-normalized eigenfunctions.
    psiny = psiy(:,1:Ny).^2;
    Iy = simp(psiny,fe);
    II = diag(1./Iy);

    NY(i) = Ny;
    PSINNORY(i,:,1:Ny) = psiny*II;
end
t1 = toc(ts)

ts = tic;
for i = 1:n
    %Step = i

    % Raws
    SCx = D-diag(V(i,:)); % Schr\"odinger operator
    [psix,lamda] = eig(SCx);% Eigenvalues & eigenfunction of Schr\"odinger operator

    % Negative eigenvalues
    temp = diag(lamda);
    kappax = -temp(temp<0);
    Nx = length(kappax);

    % The associated $L^2$-normalized eigenfunctions.
    psinx = psix(:,1:Nx).^2;
    Iy = simp(psinx,fe);
    II = diag(1./Iy);
    psinnorx = psinx*II;
    %
    for j = 1: n
        Kap = (repmat(kappax,1,NY(j)) + repmat(KAPPAY(j,1:NY(j)),Nx,1));
        if gm == 4
            Kap = Kap.*(Kap);Kap = Kap.*(Kap);
        elseif gm == 3
            Kap1 = Kap;
            Kap = Kap.*(Kap);Kap = Kap.*(Kap1);
        elseif gm == 2
            Kap = Kap.*(Kap);
        else
            Kap = Kap.^(gm);
        end
        PSINY = reshape(PSINNORY(j,i,1:NY(j)),NY(j),1);
        V1(i,j) = (h2L)*(psinnorx(j,1:Nx)*Kap*(PSINY));
    end
end
t2 = toc(ts)

V2 = (V1.^(1/(gm+1)));

ERR =(abs(img-V2))./max(max(img)); % Relatif error

MSE = mean2((img - V2).^2)
PSNR = 10*log10(1/MSE)