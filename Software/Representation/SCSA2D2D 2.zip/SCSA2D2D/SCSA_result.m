%*******************************************************************************
%  SCSA Parameter used for C-Code execution  

% direct_data='./';
% fid = fopen(strcat(direct_data,'scsa_parameters.dat'),'r');
% scsa_param = fread(fid,inf,'double');
% fclose(fid);
% 
% h = scsa_param(2);
% img_size= scsa_param(1);
% gm = scsa_param(4);
% fe = scsa_param(3);
h=0.7;gm=1;fe=1;
type_format='single';
% type_format='double';

%*******************************************************************************
load('var.mat','idx')
N=64;
direct_data='./';
fid = fopen(strcat(direct_data,'scsa_original',num2str(N),'.dat'),'r');
image_buffer = fread(fid,inf,type_format);
fclose(fid);
img_size=sqrt(max(size(image_buffer)));
original_image=reshape(image_buffer, img_size, img_size);
original_image=single(original_image);


fid = fopen(strcat(direct_data,'scsa_input',num2str(N),'.dat'),'r');
image_buffer = fread(fid,inf,type_format);
fclose(fid);
img_size=sqrt(max(size(image_buffer)));
noisy_image=reshape(image_buffer, img_size, img_size);
noisy_image=single(noisy_image);


fid = fopen(strcat(direct_data,'scsa_in_not_processed.dat'),'r');
upload_buffer_in = fread(fid,inf,type_format);
fclose(fid);

img_size=sqrt(max(size(upload_buffer_in)));

factr=0;
img_size=img_size/(2^factr);

check_C__image=reshape(upload_buffer_in, img_size, img_size);
check_C__image=single(check_C__image);

FileID = fopen(strcat(direct_data,'scsa_output.dat'),'r');
upload_buffer_out = fread(FileID,inf,type_format);
fclose(FileID);

denoised_image=reshape(upload_buffer_out, img_size, img_size);
denoised_image=single(denoised_image);

%% Evaluation with original 

ERR0 =(abs(noisy_image-original_image))./max(max(check_C__image)); % Relatif error
MSE1 = mean2((noisy_image - original_image).^2);
[PSNR1 SNR]=psnr(noisy_image,original_image);
SSIM1=ssim(noisy_image,original_image);
psnr_msg=strcat(' PSNR =   ',num2str(PSNR1),' SSIM =   ',num2str(SSIM1));

%% Plots


figure(2)

subplot(2,2,1);imshow(original_image,[]);
               title(strcat('Original Image: Size =',num2str(img_size),'*',num2str(img_size))) ;

subplot(2,2,2);imshow(check_C__image,[]);
               title(strcat('Noisy Image: ',psnr_msg)) ;
               
            

%% Evaluation denoising

ERR_image =(abs(denoised_image-original_image))./max(max(original_image)); % Relatif error

MSE1 = mean2((denoised_image - original_image).^2);
[PSNR1 SNR]=psnr(denoised_image,original_image);
SSIM1=ssim(denoised_image,original_image);
psnr_msg=strcat(' PSNR =   ',num2str(PSNR1),' SSIM =   ',num2str(SSIM1));

               
subplot(2,2,3);imshow(denoised_image,[]);title('Denoised Image') ;
                title(strcat('Denoised Image: ',psnr_msg)) ;
                xlabel(strcat(' Size =',num2str(img_size),'*',num2str(img_size),'  h=',num2str(h),'  gm=',num2str(gm),'  fe=',num2str(fe))) ;
                ylabel(' C++ implementation 2D2D. ') ;
                 
subplot(2,2,4);imshow(ERR_image,[]);title('Residual Image') ;

                 
set(figure(2),'units','normalized','outerposition',[0 0 1 1])
% saveas(figure(1),strcat('.\Results\C_implementation_RSL_',num2str(idx),'.bmp'));    
% idx=idx+1;
% save('var.mat','idx')
