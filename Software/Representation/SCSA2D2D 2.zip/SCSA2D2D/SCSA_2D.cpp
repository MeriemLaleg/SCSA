
/**
2D SCSA Image Filtering
 *
 - -* (C) Copyright 2016 King Abdullah University of Science and Technology
 Authors:
 Abderrazak Chahid (abderrazak.chahid@kaust.edu.sa)
 Taous-Meriem Laleg (taousmeriem.laleg@kaust.edu.sa)
 *
 * New function get added to code, CHAHID ROUTINE, Some variable have been changed 
 * (Class_SCSA = baboon_opts, Objet_SCSA=opts, )
 * Based on  Program written on 2015 by : 

 Ali Charara (ali.charara@kaust.edu.sa)
 David Keyes (david.keyes@kaust.edu.sa)
 Hatem Ltaief (hatem.ltaief@kaust.edu.sa)
 Taous-Meriem Laleg (taousmeriem.laleg@kaust.edu.sa)
 
 Redistribution  and  use  in  source and binary forms, with or without
 modification,  are  permitted  provided  that the following conditions
 are met:
 
 * Redistributions  of  source  code  must  retain  the above copyright
 * notice,  this  list  of  conditions  and  the  following  disclaimer.
 * Redistributions  in  binary  form must reproduce the above copyright
 * notice,  this list of conditions and the following disclaimer in the
 * documentation  and/or other materials provided with the distribution.
 * Neither  the  name of the King Abdullah University of Science and
 * chahid1/Excution_first/Code_first 
 * Technology nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 *
 *
 THIS  SOFTWARE  IS  PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 ``AS IS''  AND  ANY  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL  DAMAGES  (INCLUDING,  BUT NOT
 LIMITED  TO,  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA,  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY  OF  LIABILITY,  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF  THIS  SOFTWARE,  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/


#include <stdio.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <vector>
#include <mkl_lapack.h>
#include <mkl_blas.h>
#include <math.h>
#include <sys/time.h>

using namespace std;

// *********************** Type DEFINITION  ***********************

// structures ==================================================================

//  Class_SCSA : it includes the needed parameter and data for SCSA algorithm

struct Class_SCSA
{
    // name of needed data in .dat format
    string  dataFileName;
    string  deltaFileName;
    
    // matrix size
    int x_dim, y_dim;
    
    // SCSA Prameter
    int d;
    float h;
    int gm;
    float fe;
    
    //paramters and flags
    
    bool verbose;
    unsigned long buffer_size;
    char jobvl;
    char jobvr;
    
};
// *********************** Type DEFINITION  ***********************

// function prototypes ==================================================================
// // prepare data
bool readInput(Class_SCSA* Objet_SCSA, float* &matBuffer);
bool writeBuffer(Class_SCSA* Objet_SCSA, long int size, float* buffer, string fileName);

// MKL_Eigen_solver
void syevd( const char jobz, const char uplo,
           const int n,
           float* a, const int lda, float* w,
           float* work, const int lwork, int* iwork, const int liwork, int info );

// // SCSA features

bool delta(int n, float* &deltaBuffer, float fex, float feh);
int parse_Objet_SCSA( int argc, char** argv, Class_SCSA *Objet_SCSA );
double gettime(void);
inline float square(float v){return v*v;}
float ipow(float v, int p){
    float res = v;
//D    cout<<endl<<" power to =" << p<<endl;
    
    for(int q = 1; q < p; q++) res *= v;
    return res;
}


// ************************ GLOBALS   ***************************

/*========================= defines  ============================*/

#define sqr(a_) ((a_)*(a_))
#define PI 3.141592653589793
#define USAGE printf("usage:\t./SCSA_2D \n \
\t --data filename\n \
\t -N image_dimension\n \
\t -d value_for_d (defaults to 2)\n \
\t -h value_for_h (defaults to 0.2)\n \
\t -gm value_for_gm (defaults to 4)\n \
\t -fe value_for_fe (defaults to 1)\n \
\t [-v] verbose_messages_ON\n \
\t --help generate this help message\n \
\n \
please consult the README file for detailed instructions.\n");


// *********************** CHAHID FUNCTION ROUTINES   ***********************

void kron_prod (float* kprod,  float* a, int ma, int na,  float* b, int mb, int nb);
bool display_Objet_SCSA( Class_SCSA *Objet_SCSA );
void Matrx_Unit(int n,int m,float *Mtx_unit);
float SC_Sum(float h, int n,float *D1,float *D2,float *V,float *SC);
bool SCSA_2D2_full(Class_SCSA* Objet_SCSA, float* imag, float* Delta_mtrx);
void Disp_matrx(int n,int m,float *Mtx_A);
void Disp_EigenValues(int n,float *Mtx_A);
float simp3(float* f, int n, float dx);

#define NUM_THREADS 40

// *********************** MAIN FUNCTION   ***********************


int main(int argc, char* argv[]){
    
    if(argc < 2){
        USAGE
        return 0;
    }
  
   
//################### Data Preparation : Load image, Deltat metrix #######################################################
 
   Class_SCSA Objet_SCSA;
    

    if(!parse_Objet_SCSA(argc, argv, &Objet_SCSA)) return -1;
   
    cout<<endl<<"******************  SCSA process has started  ******************"<< endl;
    
    if(!display_Objet_SCSA( &Objet_SCSA )) return -1;                               // Display
    
    float *matBuffer = NULL, *deltaBuffer = NULL, feh = 2.0*PI / Objet_SCSA.x_dim;
    
    if(!delta(Objet_SCSA.x_dim, deltaBuffer, Objet_SCSA.fe, feh)) return -1;
    cout<<" --> Delta matrix has been generated."<<endl;
    
//EX    Disp_matrx(Objet_SCSA.x_dim,Objet_SCSA.y_dim,deltaBuffer);
    
    if(!readInput(&Objet_SCSA, matBuffer)) return -1;
    
//EX    Disp_matrx(Objet_SCSA.x_dim,Objet_SCSA.y_dim,matBuffer);
    int Nb_loop=4;
    
  
    
     //########################## Start  of SC_hhD Generation #######################################################
    double timer = 0.0, timer0 = 0.0;
    timer0 = gettime();
    
    
    float h=Objet_SCSA.h,gm = Objet_SCSA.gm,fe = Objet_SCSA.fe, h2 = h*h,d;
    int N = Objet_SCSA.x_dim,M = Objet_SCSA.y_dim, N2 = N*M, lda = N;//, i,j,k;
     
     if(Objet_SCSA.verbose) printf("allocating memory...\n");
     
   
    
     
     double comp_time0 = 0.0,time_eig=0.0,time_Psinnor=0.0, time_reconst=0.0,comp_end=0.0;
     
     if(Objet_SCSA.verbose) printf("starting first loop... Begin, please wait ... :) \n");
     
     cout<<" --> The SCSA process has started. Please, Wait few seconds! : "<<endl<<endl;
     
    
     
     //*****************************************************************************************
     
     
     //M2
     //M2 % = = = = = =   The SCSA Method
     //M2 V = img;
     //M2 n = size(V,1); fe = 1; feh = 2*pi/n;
     //M2 h = 0.2550; gm = 1;
     //M2 UC = (1/(4*pi))*gamma(gm+1)/gamma(gm+2);
     //M2 h2L = h^2/UC;
     //M2
     
     fe=1,feh=2.0*PI / N;
     h=0.2550, gm = 1;
     
     
     float UC = (1.0/(4.0*PI))*tgamma(gm+1.0)/tgamma(gm+2.0);
     float h2L = (h*h)/UC;
    
     //M2 D1 = Delta_1D(n,fe,feh);
     // already computed and stored in Var "D"
     
     //M2
     //M2 I = eye(n);

     
     float I[N*N];
     
     Matrx_Unit( N,M, I);
    
   //EX cout<<endl<<" --> Unity Matrix"<<endl;

   //EX Disp_matrx( N,M, I);
     
     
     //M2 L = sparse(n*n,n*n);         % Reduce the memory starage
     //M2 L = kron(I,D1) + kron(D1,I); % The 2D Laplacian operator
     //M2
     
     
     float Krn_prod1[N2*N2],Krn_prod2[N2*N2];
     kron_prod (Krn_prod1,I , N, N,  deltaBuffer, N, N);

     //EX cout<<endl<<" --> Krn_prod1 Matrix"<<endl;
     //EX Disp_matrx( N2,N2, Krn_prod1);
     
     kron_prod (Krn_prod2,deltaBuffer , N, N,  I, N, N);
    
     //EX cout<<endl<<" --> Krn_prod2 Matrix"<<endl;
      //EX Disp_matrx( N2,N2, Krn_prod2);
     
     //M2 V = V(:) ;
     //M2 SC = -h*h*L-diag(V); % The 2D Schr\"odinger operator
     //M2
     
    float SC_hhD[N2*N2],max_img;
    
     max_img=SC_Sum(h,N2,Krn_prod1,Krn_prod2,matBuffer,SC_hhD);
    
     cout<<endl<<" --> SC_hhD Matrix Has been generated succesfully "<<endl;
    //EX Disp_matrx( N2,N2, SC_hhD);                            // SC_hhD=SC mtrix
    

    
    //M2  [psi,lambda] = eig(SC); % Eigenvalues & eigenfunction of Schr\"odinger operator
    
    
    
    
    int N4=N2*N2, lwork = 1 + 6*N2 + 2*N4, liwork = 3 + 5*N2;
    float lamda[N2];//, lamdai[n];
    float work[lwork];
    int iwork[liwork], info;
    int Nh_size = 0;
    
    
    memset(lamda, 0, N2*sizeof(float));
    // memset(work, 0, N2*N2*sizeof(float));
   

     //M2 tic
     comp_time0 = gettime();
    
    // computes all eigenvalues and, optionally, eigenvectors of a
    // real symmetric matrix SC  when its Lower triangle  is stored.
    
    syevd( 'V', 'L',
          N2,
          SC_hhD, N2, lamda,
          work, lwork, iwork, liwork, info );
    
    if (info == 0)
        cout<<endl<<" The Eigenvalues and their corresponsing  orthonormal eigenvectors are computed   successfully of SC_hhD "<<endl<<endl;
  
    //M2  time_eig = toc;
    time_eig = gettime() - comp_time0;
    
     
     //####################### End of SC_hhD Generation #################################################
     
   //if(!writeBuffer(&Objet_SCSA,5,SC_hhD,"SCSA_2D.dat")) return -1;   // save te SC_hhd Matrix
      
    
    timer = gettime() - timer0;
    
    cout<<endl<<endl<<"****************** 2D2 SCSA Diagnosis  ******************"<<endl<<endl;
    cout<<" The computations are done with the following results :  "<< endl;
    cout<< "==> Execution Time:  ============= = "<<timer<< " sec"<< endl;
    cout<< "==> Execution Time:  EigenAnalysis = "<<time_eig<< " sec"<< endl;
    

    delete matBuffer;
    delete deltaBuffer;
    
    return 0;
}

// *********************** FUNCTION ROUTINES   ***********************




/*============================= DELTA MATRIX   ==================================
 ____________________________________________________________________________
 | This function returns D matrix, where deltaBuffer is a second order        |
 | differentiation matrix obtained by using the Fourier pseudospectral mehtod |
 | __________________________________________________________________________ |*/

bool delta(int n, float* &deltaBuffer, float fex, float feh){
    int ex, p;//float ex[n-1];
    float dx, test_bx[n-1], test_tx[n-1], factor = feh/fex;
    factor *= factor;
    
    if(n%2 == 0){
        p = 1;
        dx = -(PI*PI)/(3.0*feh*feh)-1.0/6.0;
        for(int i = 0; i < n-1; i+=2){
            ex = n-i-1;
            p *= -1;
            test_bx[i] = test_tx[i] = -0.5 * p / square(sin( ex * feh * 0.5));
            ex = n-i-2;
            p *= -1;
            test_bx[i+1] = test_tx[i+1] = -0.5 * p / square(sin( ex * feh * 0.5));
        }
    }else{
        dx = -(PI*PI) / (3.0*feh*feh) - 1.0/12.0;
        for(int i = 0; i < n-1; i++){
            ex = n-i-1;
            test_bx[i] = -0.5 * pow(-1,  ex) * cot( ex * feh * 0.5) / (sin( ex * feh * 0.5));
            test_tx[i] = -0.5 * pow(-1, -ex) * cot(-ex * feh * 0.5) / (sin(-ex * feh * 0.5));
            
            //$            test_bx[i] = -0.5 * pow(-1,  ex) * cos( ex * feh * 0.5) / (sin( ex * feh * 0.5));
            //$            test_tx[i] = -0.5 * pow(-1, -ex) * cos(-ex * feh * 0.5) / (sin(-ex * feh * 0.5));
        }
    }
    
    unsigned long buffer_size = n * n;
    deltaBuffer = new float[ buffer_size ];
    if(!deltaBuffer)
    {
        cout << "out of memory, could not allocate "<< buffer_size <<" of memory!" << endl;
        return false;
    }
    
    int lda = n+1;
    
    for(int r = 0; r < n; r++){
        deltaBuffer[r*lda] = dx * factor;
    }
    float vL, vU;
    for(int r = 1; r < n; r++){
        vL = test_bx[n-r-1] * factor;
        vU = test_tx[n-r-1] * factor;
        
        for(int c = 0; c < n-r; c++){
            deltaBuffer[r   + c*lda] = vL;
            deltaBuffer[r*n + c*lda] = vU;
        }
    }
    return true;
}


/*================================ READ DATA    ===============================
 ____________________________________________________________________________
 |         This function  reads the ".dat" file stored in Objet_SCSA          |
 |                  to the buffer (table Pointer )  matBuffer                 |
 | __________________________________________________________________________ |*/


bool readInput(Class_SCSA* Objet_SCSA, float* &matBuffer)//, float* &deltaBuffer)
{
    if(Objet_SCSA->verbose) cout << "reading data from file: " << Objet_SCSA->dataFileName << ", data of size: " << Objet_SCSA->x_dim << "x" << Objet_SCSA->y_dim << endl;
    FILE* infile;
    //load matrix data
//     cout<<" -->  The image read is : "<< Objet_SCSA->dataFileName.c_str();
    infile = fopen(Objet_SCSA->dataFileName.c_str(), "rb");
    if(!infile)
    {
        cout << "could not open input file!" << endl; return 0;
    }
    
    Objet_SCSA->buffer_size = Objet_SCSA->x_dim * Objet_SCSA->y_dim;
    
    if(Objet_SCSA->verbose) cout << "reading buffer of size: " << Objet_SCSA->buffer_size << endl;
    matBuffer = new float[ Objet_SCSA->buffer_size ];
    if(!matBuffer)
    {
        cout << "out of memory, could not allocate "<< Objet_SCSA->buffer_size <<" of memory!" << endl;
        fclose(infile);
        return false;
    }
    unsigned long res = fread((void*)matBuffer, sizeof(float), Objet_SCSA->buffer_size, infile);
    if(ferror(infile)){
        cout << "error reading file!" << endl;
    }
    if(Objet_SCSA->verbose) cout << "did read " << res << " entries, content not checked though!" << endl;
    fclose(infile);
    
    return true;
}


/*========================= WRITE results  DATA    ===========================
 ____________________________________________________________________________
 |       This function writes the the buffer (table Pointer )  buffer         |
 |                   to  "fileName.dat" of Objet_SCSA                         |
 | __________________________________________________________________________ |*/

bool writeBuffer(Class_SCSA* Objet_SCSA, long int size, float* buffer, string fileName)
{
    if(Objet_SCSA->verbose) cout << "writeing data to file: " << fileName << ", data of size: " << size << endl;
    FILE* outfile;
    //load matrix data
    outfile = fopen(fileName.c_str(), "wb");
    if(!outfile)
    {
        cout << "could not open output file!" << endl; return 0;
    }
    
    unsigned long res = fwrite((void*)buffer, sizeof(float), size, outfile);
    if(ferror(outfile)){
        cout << "error writing to file!" << endl;
        return 0;
    }
    fclose(outfile);
    
    cout<<endl<<" --> "<<fileName<<" has been created succefully."<<endl<<endl;
    return true;
}

/*===================== SCSA Object reconstruction     =======================
 ____________________________________________________________________________
 | This function contains the differents information of about the input data  |
 | to process, Moreover it stores also SCSA parameters to use in the Process  |
 |              All in type structure object called  Objet_SCSA               |
 | __________________________________________________________________________ |*/


int parse_Objet_SCSA( int argc, char** argv, Class_SCSA *Objet_SCSA )
{
    // fill in default values
    Objet_SCSA->x_dim = 512;
    Objet_SCSA->y_dim = 512;
    
    Objet_SCSA->d = 2;
    Objet_SCSA->h = 0.255;
    Objet_SCSA->gm = 1;
    Objet_SCSA->fe = 1.0;
    //Objet_SCSA->L = 0.015915494309190;
    Objet_SCSA->dataFileName = "baboon_b.dat";
    Objet_SCSA->deltaFileName = "baboon_D.dat";
    Objet_SCSA->jobvl = 'N';
    Objet_SCSA->jobvr = 'V';
    Objet_SCSA->verbose= false;
    
    int info;
    for( int i = 1; i < argc; ++i ) {
        // ----- matrix size
        // each -N fills in next entry of size
        if ( strcmp("-N", argv[i]) == 0 && i+1 < argc ) {
            i++;
            int m, n;
            info = sscanf( argv[i], "%d:%d", &m, &n);
            if ( info == 2 && m > 0 && n > 0 ) {
                Objet_SCSA->x_dim = m;
                Objet_SCSA->y_dim = n;
            }
            else if ( info == 1 && m >= 0 ) {
                Objet_SCSA->x_dim = m;
                Objet_SCSA->y_dim = m;// implicitly
            }
            else {
                fprintf( stderr, "error: -N %s is invalid; ensure m >= 0, n >= 0, info=%d, m=%d, n=%d.\n",
                        argv[i],info,m,n);
                exit(1);
            }
        }
        
        
        else if ( strcmp("--data", argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->dataFileName = argv[++i];
        }
        else if ( strcmp("--delta", argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->deltaFileName = argv[++i];
        }
        else if ( strcmp("-d",    argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->d = atoi( argv[++i] );
        }
        else if ( strcmp("-h", argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->h = atof( argv[++i] );
        }
        else if ( strcmp("-fe", argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->fe = atof( argv[++i] );
        }
        else if ( strcmp("-gm",   argv[i]) == 0 && i+1 < argc ) {
            Objet_SCSA->gm = atoi( argv[++i] );
            //Objet_SCSA->L = 1.0 / (4*PI*(Objet_SCSA->gm+1));
        }/*
          else if ( strcmp("-L", argv[i]) == 0 && i+1 < argc ) {
          Objet_SCSA->L = atof( argv[++i] );
          }*/
        else if ( strcmp("-v",  argv[i]) == 0 ) { Objet_SCSA->verbose= true;  }
        
        // ----- usage
        else if ( strcmp("--help", argv[i]) == 0 ) {
            USAGE
            exit(0);
        }
        else {
            fprintf( stderr, "error: unrecognized option %s\n", argv[i] );
            exit(1);
        }
    }
    
    return 1;
}


/*========================== Time measurement     ============================
 ____________________________________________________________________________
 |       This function returns the actual time in secondes                   |
 | __________________________________________________________________________ |*/

double gettime(void)
{
    struct timeval tp;
    gettimeofday( &tp, NULL );
    
    return tp.tv_sec + 1e-6 * tp.tv_usec;
}


// *********************** CHAHID FUNCTION ROUTINES   ***********************

/*======================== Kronecker product   ===================
 __________________________________________________________________
 | This function returns the Kronecker product of A AND B           |
 | ________________________________________________________________ |*/


void kron_prod (float* kprod,  float* a, int ma, int na,  float* b, int mb, int nb)
{
    int         i, j, k, l;
    int         np = na * nb;
    
    for (i = 0; i < ma; ++ i)
        for (j = 0; j < na; ++ j)
            for (k = 0; k < mb; ++ k)
                for (l = 0; l < nb; ++ l)
                    
                    //row= (i-1)*nb+l;
                    // col=(j-1)*mb+k;
                    
                    // slice_a=(j-1)*na+i;
                    //slice_b=(k-1)*nb+l;
                    
                    
                    //c((col-1)*na*nb+row)=a(slice_a)*b(slice_b);
                   
                    kprod[(j*mb+k)*na*nb+(i*nb+l)] = a[j*na+i] * b[k*nb+l];
    
}


/*======================== unity Matrix   ===================
 __________________________________________________________________
 |              This function returns unity Matrix                  |
 | ________________________________________________________________ |*/

void Matrx_Unit(int n,int m,float *Mtx_unit){
    
    memset(Mtx_unit, 0, n*m*sizeof(float));
    
    int n2=n*m,step=0;
    
    for (int j=0; j<n2; j+=n) {
        Mtx_unit [j+step]=1;
        step++;
    }
}

/*======================== SUM matrix   ===================
 __________________________________________________________________
 |  This function returns the sum of A and B matrix  Matrix        |
 |________________________________________________________________ |*/

float SC_Sum(float h, int n,float *D1,float *D2,float *V,float *SC) {
    
    int step=0;
    float max_img0=0.0;
    
//     cout<<endl<< "-h*h="<< -h*h<<endl;
    
    for (int j=0; j<n*n; j++) {
        
        SC[j]=(-h*h)*(D1[j]+D2[j]);
        
//D         cout<<endl<< "| L = "<< D1[j]<<" + "<<D2[j];

//D         cout<<endl<< "|"<< j<<"  "<<j%(n+1)<<" == "<<SC[j];
        
        if (j%(n+1)==0){
            
            SC[j]=SC[j]-V[step];
            
            max_img0=(V[step]>max_img0?V[step]:max_img0);

//D            cout<<"- "<<V[step]<< "|";
            step++;
            
          }
        
        
    }
    return max_img0;
    
}
/*======================== Displays   ===================
 __________________________________________________________________
 | This function Shows the buffer in  Matrix representation         |
 | ________________________________________________________________ |*/

 void Disp_matrx(int n,int m,float *Mtx_A) {
   // cout<<endl<<" _______  Displaying Buffer :"<< n*m<<" Values __________"<<endl<<endl;
     
   //  for (int i=0; i<n*m; i++){
    //     printf(" | %f | ",Mtx_A [i] );}
     
cout<<endl<<endl<<" __________  Displaying Matrix :"<< n<<"X"<<m<<" _____________"<<endl<<endl;
     
    for (int i=0; i<n; i++) {
         for (int j=0; j<m; j++) {
        
                printf(" | %f | ",Mtx_A [i+j*n] );
             }
            
      printf(" \n");}
    
 }



/*======================== Displays   ===================
 __________________________________________________________________
 | This function Shows the buffer in  Matrix representation         |
 | ________________________________________________________________ |*/

void Disp_EigenValues(int n,float *Vector_A) {

    printf(" \n\n_______  Displaying Eigen Values  Vector  __________\n\n");
    
    for (int j=0; j<n; j++) {
        
        printf(" | %f | ",Vector_A[j] );
        
        
    }
    
    
    
}

/*=========================== 2D SCSA PROCESS   =============================
 
 ___________________________________________________________________________
 | This function returns 2D SCSA PROCESS with paramters stored in  Objet_SCSA|
 | _________________________________________________________________________ |
 
 THE ORIGINAL MATLAB CODE:
 %==========================================================================
 %     Recostruction of Lena's image using 2D SCSA formula without using
 % separation of variables for $h = ...$ and $\gamma=1$
 %
 % http://sipi.usc.edu/database/database
 %
 %   Author: Zineb Kaisserli and Meriem Laleg
 %    December 20th, 2014
 %==========================================================================*/

bool SCSA_2D2_full(Class_SCSA* Objet_SCSA, float* imag, float* Delta_mtrx){
    
   return 1;
}


/*======================= Display  Image information    =======================
 
 ___________________________________________________________________________
 |   This function displays the image information stored in  Objet_SCSA     |
 | _________________________________________________________________________|*/
 



bool display_Objet_SCSA( Class_SCSA *Objet_SCSA )
{
    cout<< " ============== Image Informations =============="<<endl;
    cout<< "|  Dimmension : " <<   Objet_SCSA->x_dim<<  " X "<<   Objet_SCSA->y_dim<< " Pixels."<<endl;
    //Objet_SCSA->L = 0.015915494309190;
    cout<< "|  Stored in file: "<<    Objet_SCSA->dataFileName <<" ."<<endl;
    cout<< "|*************** SCSA Parameters *****************"<<endl;
    cout<< "| h== "<<Objet_SCSA->h << "    d="<< Objet_SCSA->d<< "    gm="<<Objet_SCSA->gm << "    fe="<<Objet_SCSA->fe << "."<<endl;
    cout<< "| jobvl= "<< Objet_SCSA->jobvl << "    jobvr="<< Objet_SCSA->jobvr<< "    verbose="<< Objet_SCSA->verbose<< "."<<endl;
    cout<< " ================================================="<<endl;
    return 1;
}



/*============================= SIMPEOMS'S RULE  ============================/*
 ___________________________________________________________________________
 | This function returns the numerical integration of a function f^2 using   |
 | Simpson method ot compute the  associated  L^2 -normalized eigenfunctions.|
 | _________________________________________________________________________ |*/


float simp3(float* f, int n, float dx){
    //M2      %  This function returns the numerical integration of a function f
    //M2      %  using the Simpson method
    //M2
    //M2      [n,~]=size(f);
    //M2      I=1/3*(f(1,:)+f(2,:))*dx;
    //M2
    //M2      for i=3:n
    //M2          if(mod(i,2)==0)
    //M2              I=I+(1/3*f(i,:)+1/3*f(i-1,:))*dx;
    //M2          else
    //M2              I=I+(1/3*f(i,:)+f(i-1,:))*dx;
    //M2          end
    //M2      end
    //M2      y=I;
    
    float I;
    I = (f[0]*f[0]+f[1]*f[1])*dx/3.0;
    
    for(int i = 2; i < n; i++){
        
        if (i % 2==0){
            I = I+(((1.0/3.0*f[i]*f[i])+f[i-1]*f[i-1])*dx);
            
        }
        
        else{
             I = I+(f[i]*f[i]+f[i-1]*f[i-1])*(dx/3.0);
                
                }

        
    }
    return I;
}


/*====================  EIGENVALUES DECOMPOSITION =============================
 __________________________________________________________________________________
 | This function computes all eigenvalues and, optionally, eigenvectors of :        |
 |  -> "a" real symmetric matrix of dmnsn "lda" with Lower triangle  is stored.     |
 |  -> If INFO = 0, "W" contains eigenvalues in ascending order.                    |
 |  -> If JOBZ = 'V', then if INFO = 0,A contains the orthonormal eigenvectors of A |
 |  -> if INFO = 0, WORK(1) returns the optimal LWORK                               |
 |  -> If JOBZ = 'V' and N > 1, LWORK must be at least:  1 + 6*N + 2*N**2.          |
 |  -> If JOBZ  = 'V' and N > 1, LIWORK must be at least 3 + 5*N.                   |
 |  -> INFO is INTEGER                                                              |
 |     = 0:  successful exit                                                        |
 |     < 0:  if INFO = -i, the i-th argument had an illegal value                   |
 |     > 0:  if INFO = i and JOBZ = 'N', then the algorithm failed                  |
 |              to converge; i off-diagonal elements of an intermediate tridiagonal |
 |              form did not converge to zero;                                      |
 |             if INFO = i and JOBZ = 'V', then the algorithm failed to compute an  |
 |               eigenvalue while working on the submatrix lying in rows and columns|
 |               INFO/(N+1) through  mod(INFO,N+1).                                 |
 | ________________________________________________________________________________ |*/

void syevd( const char jobz, const char uplo,
           const int n,
           float* a, const int lda, float* w,
           float* work, const int lwork, int* iwork, const int liwork, int info ){
    
    
    cout<<endl<<endl<<" --> Eigen Analysis of the Matrix SC_hhD . "<<endl;
    
    ssyevd( &jobz, &uplo,
           &n,
           a, &lda, w,
           work, &lwork, iwork, &liwork, &info );
    
}













/*   Comment
  //EX  : displays during execution
 
  //D1  :
 
 
 */

